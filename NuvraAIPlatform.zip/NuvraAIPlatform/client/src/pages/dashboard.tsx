import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Playground from "@/components/playground";
import ApiKeys from "@/components/api-keys";
import UsageAnalytics from "@/components/usage-analytics";
import Billing from "@/components/billing";
import {
  Brain,
  Play,
  Key,
  BarChart3,
  CreditCard,
  Settings,
  LogOut,
} from "lucide-react";

type DashboardPage = "playground" | "api-keys" | "usage" | "billing" | "settings";

export default function Dashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [currentPage, setCurrentPage] = useState<DashboardPage>("playground");

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return null; // Will redirect via useEffect
  }

  const sidebarItems = [
    {
      id: "playground" as const,
      label: "Playground",
      icon: Play,
      description: "Test AI models",
    },
    {
      id: "api-keys" as const,
      label: "API Keys",
      icon: Key,
      description: "Manage your keys",
    },
    {
      id: "usage" as const,
      label: "Usage",
      icon: BarChart3,
      description: "View analytics",
    },
    {
      id: "billing" as const,
      label: "Billing",
      icon: CreditCard,
      description: "Manage subscription",
    },
  ];

  const renderCurrentPage = () => {
    switch (currentPage) {
      case "playground":
        return <Playground />;
      case "api-keys":
        return <ApiKeys />;
      case "usage":
        return <UsageAnalytics />;
      case "billing":
        return <Billing />;
      default:
        return <Playground />;
    }
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <Sidebar className="border-r border-sidebar-border bg-sidebar">
          <SidebarHeader className="border-b border-sidebar-border p-6">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
                <Brain className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-bold text-sidebar-foreground">Nuvra AI</span>
            </div>
          </SidebarHeader>

          <SidebarContent>
            <SidebarMenu className="p-4">
              {sidebarItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton
                    onClick={() => setCurrentPage(item.id)}
                    isActive={currentPage === item.id}
                    className="w-full justify-start p-3 rounded-lg transition-colors"
                    data-testid={`sidebar-${item.id}`}
                  >
                    <item.icon className="w-4 h-4 mr-3" />
                    <div className="text-left">
                      <div className="font-medium">{item.label}</div>
                      <div className="text-xs text-sidebar-foreground/60">{item.description}</div>
                    </div>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>

            {/* User Profile */}
            <div className="mt-auto p-4 border-t border-sidebar-border">
              <div className="flex items-center space-x-3 p-3 rounded-lg bg-sidebar-accent">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={user.profileImageUrl || ""} alt={user.firstName || ""} />
                  <AvatarFallback className="bg-primary text-primary-foreground text-sm">
                    {user.firstName?.[0] || user.email?.[0] || "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sidebar-foreground truncate">
                    {user.firstName ? `${user.firstName} ${user.lastName || ""}`.trim() : "User"}
                  </div>
                  <div className="text-xs text-sidebar-foreground/60 truncate">
                    {user.email}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  asChild
                  className="p-2 h-8 w-8 text-sidebar-foreground/60 hover:text-sidebar-foreground"
                  data-testid="logout-button"
                >
                  <a href="/api/logout">
                    <LogOut className="w-4 h-4" />
                  </a>
                </Button>
              </div>
            </div>
          </SidebarContent>
        </Sidebar>

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <header className="border-b border-border p-4 bg-background/80 backdrop-blur-sm">
            <div className="flex items-center">
              <SidebarTrigger className="md:hidden mr-4" />
              <div>
                <h1 className="text-2xl font-bold text-foreground capitalize">
                  {currentPage === "api-keys" ? "API Keys" : currentPage}
                </h1>
                <p className="text-sm text-muted-foreground">
                  {currentPage === "playground" && "Test AI models in real-time"}
                  {currentPage === "api-keys" && "Manage your API keys"}
                  {currentPage === "usage" && "Monitor your API usage and costs"}
                  {currentPage === "billing" && "Manage your subscription and billing"}
                </p>
              </div>
            </div>
          </header>

          <main className="flex-1 overflow-auto bg-background">
            {renderCurrentPage()}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
