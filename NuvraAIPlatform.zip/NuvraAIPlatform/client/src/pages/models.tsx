import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Brain,
  Search,
  Filter,
  ArrowRight,
  Star,
  Code,
  MessageSquare,
  Image as ImageIcon,
  Mic,
  Video,
  Zap,
} from "lucide-react";

interface Model {
  id: string;
  name: string;
  provider: string;
  type: string;
  context: string;
  status: string;
  description: string;
}

const modelCategories = [
  { id: "all", name: "All Models", icon: Brain },
  { id: "chat", name: "Chat", icon: MessageSquare },
  { id: "code", name: "Code Generation", icon: Code },
  { id: "image", name: "Image Generation", icon: ImageIcon },
  { id: "voice", name: "Voice Generation", icon: Mic },
  { id: "video", name: "Video Generation", icon: Video },
];

const getProviderIcon = (provider: string) => {
  const icons: Record<string, string> = {
    "OpenAI": "🧠",
    "Anthropic": "🤖", 
    "Google": "⚡",
    "DeepSeek": "🔮",
    "Alibaba": "🔥",
    "xAI": "💫",
  };
  return icons[provider] || "🤖";
};

const getProviderColor = (provider: string) => {
  const colors: Record<string, string> = {
    "OpenAI": "bg-green-500",
    "Anthropic": "bg-orange-500",
    "Google": "bg-blue-500", 
    "DeepSeek": "bg-purple-500",
    "Alibaba": "bg-red-500",
    "xAI": "bg-gray-600",
  };
  return colors[provider] || "bg-gray-500";
};

export default function Models() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedProvider, setSelectedProvider] = useState("all");

  const { data: models = [], isLoading } = useQuery<Model[]>({
    queryKey: ["/api/models"],
  });

  // Filter models based on search and category
  const filteredModels = models.filter((model: Model) => {
    const matchesSearch = model.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         model.provider.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         model.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === "all" || 
                          model.type.toLowerCase().includes(selectedCategory.toLowerCase());
    
    const matchesProvider = selectedProvider === "all" || 
                          model.provider.toLowerCase() === selectedProvider.toLowerCase();

    return matchesSearch && matchesCategory && matchesProvider;
  });

  const providers = ["all", ...Array.from(new Set(models.map((m: Model) => m.provider)))];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="animate-pulse space-y-8">
            <div className="h-12 bg-muted rounded-lg"></div>
            <div className="grid md:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-48 bg-muted rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Models Gallery
          </h1>
          <p className="text-xl text-muted-foreground mb-8">
            Explore our collection of 300+ AI models
          </p>
        </div>

        {/* Featured Model Banner */}
        <Card className="glass-card mb-12 overflow-hidden">
          <div className="relative bg-gradient-to-r from-primary/10 to-secondary/10">
            <CardContent className="p-8">
              <div className="grid lg:grid-cols-2 gap-8 items-center">
                <div>
                  <Badge className="mb-4">New API Model</Badge>
                  <h2 className="text-3xl font-bold text-foreground mb-4">
                    GPT-5 Is Live – Try Today!
                  </h2>
                  <p className="text-muted-foreground mb-6 text-lg">
                    GPT-5 delivers real-time, high-quality text generation that adapts 
                    effortlessly to a wide range of applications with a 400K token context window.
                  </p>
                  <Button asChild data-testid="try-gpt5-button">
                    <Link href="/dashboard">
                      Try GPT-5 <ArrowRight className="ml-2 w-4 h-4" />
                    </Link>
                  </Button>
                </div>
                <Card className="bg-card/50 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center text-white text-2xl">
                        🧠
                      </div>
                      <div>
                        <div className="font-bold text-lg">GPT-5</div>
                        <div className="text-muted-foreground">OpenAI</div>
                      </div>
                      <Badge className="ml-auto">NEW</Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Model type:</span>
                        <span>Chat</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Status:</span>
                        <Badge variant="default">Active</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Context:</span>
                        <span>400K tokens</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </div>
        </Card>

        {/* Filters */}
        <Card className="glass-card mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4 items-center">
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm font-medium">Filters:</span>
              </div>
              
              {/* Category Buttons */}
              <div className="flex flex-wrap gap-2">
                {modelCategories.map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category.id)}
                    className="flex items-center space-x-2"
                    data-testid={`filter-${category.id}`}
                  >
                    <category.icon className="w-4 h-4" />
                    <span>{category.name}</span>
                  </Button>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row gap-4 ml-auto">
                {/* Provider Filter */}
                <Select value={selectedProvider} onValueChange={setSelectedProvider}>
                  <SelectTrigger className="w-40" data-testid="provider-filter">
                    <SelectValue placeholder="All Providers" />
                  </SelectTrigger>
                  <SelectContent>
                    {providers.map((provider) => (
                      <SelectItem key={provider} value={provider}>
                        {provider === "all" ? "All Providers" : provider}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Search */}
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search models..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 w-64"
                    data-testid="model-search"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Models Grid */}
        {filteredModels.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <div className="w-16 h-16 mx-auto bg-muted rounded-full flex items-center justify-center mb-4">
                <Search className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2">No models found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your search criteria or filters
              </p>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSearchQuery("");
                  setSelectedCategory("all");
                  setSelectedProvider("all");
                }}
              >
                Clear Filters
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {filteredModels.map((model: Model, index) => (
              <Card
                key={model.id}
                className="hover:shadow-lg transition-all duration-200 hover:scale-[1.02] glass-card animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
                data-testid={`model-card-${model.id}`}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-12 h-12 ${getProviderColor(model.provider)} rounded-lg flex items-center justify-center text-white text-xl`}>
                        {getProviderIcon(model.provider)}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{model.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">{model.provider}</p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end space-y-1">
                      {model.name.includes("GPT-5") && <Badge variant="default">PRO</Badge>}
                      {model.name.includes("Claude") && <Badge variant="default">PRO</Badge>}
                      {model.name.includes("V3.1") && <Badge className="bg-purple-500">NEW</Badge>}
                      {model.name.includes("Grok") && <Badge variant="secondary">BETA</Badge>}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Type:</span>
                      <span>{model.type}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Context:</span>
                      <span>{model.context}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Status:</span>
                      <Badge 
                        variant={model.status === "active" ? "default" : "secondary"}
                        className="text-xs"
                      >
                        {model.status}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {model.description}
                  </p>
                  <Button 
                    className="w-full" 
                    asChild 
                    data-testid={`try-model-${model.id}`}
                  >
                    <Link href="/dashboard">
                      Try Model <Zap className="ml-2 w-4 h-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Load More / View All */}
        <div className="text-center">
          <p className="text-muted-foreground mb-4">
            Showing {filteredModels.length} of {models.length} models
          </p>
          <Button variant="outline" asChild data-testid="view-all-models">
            <Link href="/dashboard">
              Try Models in Playground <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
