import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Check, ArrowRight, Zap, Shield, Clock, Users, Star } from "lucide-react";

interface PricingPlan {
  id: string;
  name: string;
  price: string;
  period?: string;
  description: string;
  features: string[];
  buttonText: string;
  popular?: boolean;
  badge?: string;
  badgeColor?: string;
}

const pricingPlans: PricingPlan[] = [
  {
    id: "developer",
    name: "Developer",
    price: "Free",
    description: "Perfect for prototypes and exploration",
    features: [
      "10 requests / hour",
      "Free Playground",
      "24/7 Human Support", 
      "Community Access",
      "Basic model access",
      "Standard rate limits",
    ],
    buttonText: "Get Started",
    popular: false,
  },
  {
    id: "startup",
    name: "Startup",
    price: "Pay As You Go",
    description: "Flexible pricing for growing businesses",
    features: [
      "Everything in Developer",
      "from 40M tokens",
      "Access to 300+ models",
      "Pay only for what you use",
      "Higher rate limits",
      "Email support",
    ],
    buttonText: "Start Building",
    popular: true,
  },
  {
    id: "production",
    name: "Production",
    price: "$50",
    period: "/month",
    description: "For mission-critical applications",
    features: [
      "Everything in Startup",
      "100M tokens included",
      "Priority Support",
      "Fixed Pricing",
      "SLA guarantee",
      "Advanced analytics",
    ],
    buttonText: "Go Production",
    badge: "+10% Tokens",
    badgeColor: "bg-green-500",
  },
  {
    id: "scale",
    name: "Scale", 
    price: "$200",
    period: "/month",
    description: "For high-volume applications",
    features: [
      "Everything in Production",
      "400M tokens included",
      "Personal manager",
      "Enterprise-grade reliability",
      "Custom integrations",
      "Phone support",
    ],
    buttonText: "Scale Up",
    badge: "+20% Tokens",
    badgeColor: "bg-blue-500",
  },
  {
    id: "crypto",
    name: "Pay In Crypto",
    price: "$100", 
    period: "/month",
    description: "Global payments with cryptocurrency",
    features: [
      "Everything in Production",
      "200M tokens included",
      "Personal manager",
      "Enterprise-grade reliability",
      "Crypto payments (BTC, ETH)",
      "Privacy focused",
    ],
    buttonText: "Pay with Crypto",
    badge: "+25% Tokens",
    badgeColor: "bg-orange-500",
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: "Custom Pricing",
    description: "Tailored solutions for large organizations",
    features: [
      "Special pricing",
      "Dedicated servers", 
      "Custom models",
      "Unlimited RPM and TPM",
      "Full staff training & integration",
      "Joint marketing activities",
      "Shared Slack channel",
      "Extended data storage",
    ],
    buttonText: "Contact Sales",
  },
];

const faqs = [
  {
    question: "What happens if I exceed my token limit?",
    answer: "You'll be charged for additional usage at standard rates. You can set usage alerts to monitor your consumption and avoid unexpected charges.",
  },
  {
    question: "Can I change my plan anytime?",
    answer: "Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately, and billing is prorated accordingly.",
  },
  {
    question: "Do you offer discounts for startups?",
    answer: "Yes, we offer special pricing for eligible startups through our startup program. Contact our sales team to learn more about qualification requirements.",
  },
  {
    question: "What payment methods do you accept?",
    answer: "We accept all major credit cards, bank transfers, and cryptocurrency payments for qualifying plans. PayPal is also supported for some regions.",
  },
  {
    question: "Is there a free trial available?",
    answer: "Yes! Our Developer plan is completely free with no time limit. You can upgrade anytime as your needs grow.",
  },
  {
    question: "What's included in enterprise support?",
    answer: "Enterprise customers get dedicated account management, priority support, custom SLAs, and direct access to our engineering team.",
  },
];

export default function Pricing() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-4">Pricing</Badge>
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            AI Plans That Grow With You
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Seamlessly scale your AI capabilities from proof-of-concept to production and beyond.
            Choose the plan that fits your needs.
          </p>
        </div>

        {/* Billing Toggle */}
        <div className="flex justify-center mb-12">
          <div className="bg-muted rounded-lg p-1">
            <button
              onClick={() => setBillingCycle("monthly")}
              className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
                billingCycle === "monthly"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              data-testid="billing-monthly"
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle("yearly")}
              className={`px-6 py-2 rounded-md text-sm font-medium transition-colors ${
                billingCycle === "yearly"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              data-testid="billing-yearly"
            >
              Yearly
              <Badge className="ml-2 text-xs">Save 20%</Badge>
            </button>
          </div>
        </div>

        {/* Pricing Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {pricingPlans.map((plan, index) => (
            <Card
              key={plan.id}
              className={`relative transition-all duration-200 hover:shadow-lg animate-fade-in ${
                plan.popular
                  ? "border-primary shadow-lg scale-105"
                  : "hover:scale-[1.02]"
              }`}
              style={{ animationDelay: `${index * 0.1}s` }}
              data-testid={`plan-${plan.id}`}
            >
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                  <Badge className="bg-primary text-primary-foreground px-4 py-1 font-semibold">
                    <Star className="w-3 h-3 mr-1" />
                    Most Popular
                  </Badge>
                </div>
              )}

              {/* Plan Badge */}
              {plan.badge && (
                <div className="absolute top-4 right-4">
                  <Badge className={`${plan.badgeColor} text-white text-xs`}>
                    {plan.badge}
                  </Badge>
                </div>
              )}

              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-foreground">
                    {plan.price}
                  </span>
                  {plan.period && (
                    <span className="text-muted-foreground ml-1">{plan.period}</span>
                  )}
                </div>
                <p className="text-muted-foreground mt-2">{plan.description}</p>
              </CardHeader>

              <CardContent>
                <Button
                  className="w-full mb-6"
                  variant={plan.popular ? "default" : "outline"}
                  asChild
                  data-testid={`plan-${plan.id}-button`}
                >
                  <Link href="/api/login">
                    {plan.buttonText}
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>

                <ul className="space-y-3">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <Check className="w-4 h-4 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
                      <span className="text-sm text-muted-foreground">
                        {feature.includes("**") ? (
                          <span dangerouslySetInnerHTML={{ 
                            __html: feature.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') 
                          }} />
                        ) : (
                          feature
                        )}
                      </span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Feature Comparison */}
        <Card className="glass-card mb-16">
          <CardHeader>
            <CardTitle className="text-center text-2xl">Why Choose Nuvra AI?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-8 text-center">
              <div className="space-y-4">
                <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center mx-auto">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold">Lightning Fast</h3>
                <p className="text-sm text-muted-foreground">
                  Sub-second response times across all models with global edge deployment.
                </p>
              </div>
              <div className="space-y-4">
                <div className="w-12 h-12 bg-chart-2/20 rounded-xl flex items-center justify-center mx-auto">
                  <Shield className="w-6 h-6 text-chart-2" />
                </div>
                <h3 className="font-semibold">Enterprise Security</h3>
                <p className="text-sm text-muted-foreground">
                  SOC 2 compliant infrastructure with end-to-end encryption.
                </p>
              </div>
              <div className="space-y-4">
                <div className="w-12 h-12 bg-chart-3/20 rounded-xl flex items-center justify-center mx-auto">
                  <Clock className="w-6 h-6 text-chart-3" />
                </div>
                <h3 className="font-semibold">99.9% Uptime</h3>
                <p className="text-sm text-muted-foreground">
                  Guaranteed uptime with automatic failover and redundancy.
                </p>
              </div>
              <div className="space-y-4">
                <div className="w-12 h-12 bg-chart-4/20 rounded-xl flex items-center justify-center mx-auto">
                  <Users className="w-6 h-6 text-chart-4" />
                </div>
                <h3 className="font-semibold">24/7 Support</h3>
                <p className="text-sm text-muted-foreground">
                  Expert support team available around the clock via chat, email, or phone.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* FAQ Section */}
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-muted-foreground">
              Everything you need to know about our pricing and plans.
            </p>
          </div>

          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="glass-card border-0 rounded-lg px-6"
                data-testid={`faq-${index}`}
              >
                <AccordionTrigger className="text-left font-semibold hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pt-2 pb-4">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16 p-12 rounded-2xl bg-gradient-to-r from-primary/10 to-secondary/10">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            Join thousands of developers building the future with AI.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild data-testid="cta-start-free">
              <Link href="/api/login">
                Start Free <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
            <Button variant="outline" size="lg" asChild data-testid="cta-contact-sales">
              <Link href="/help">
                Contact Sales
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
