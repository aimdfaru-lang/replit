import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Search,
  User,
  Info,
  CreditCard,
  Monitor,
  Bug,
  Code,
  MessageCircle,
  Mail,
  Phone,
  ArrowRight,
  CheckCircle,
  Clock,
  AlertCircle,
  HelpCircle,
} from "lucide-react";

interface HelpCategory {
  id: string;
  title: string;
  description: string;
  icon: any;
  articleCount: number;
  color: string;
}

const helpCategories: HelpCategory[] = [
  {
    id: "account",
    title: "Account Management",
    description: "Learn how to manage your account — update profile details and secure access",
    icon: User,
    articleCount: 8,
    color: "bg-blue-500",
  },
  {
    id: "general",
    title: "General Information", 
    description: "Explore Nuvra AI overview, features, and FAQs for key platform information",
    icon: Info,
    articleCount: 12,
    color: "bg-green-500",
  },
  {
    id: "billing",
    title: "Payments and Pricing",
    description: "Understand Nuvra AI pricing, payment methods, invoices, and billing questions",
    icon: CreditCard,
    articleCount: 15,
    color: "bg-yellow-500",
  },
  {
    id: "platform",
    title: "Platform Usage",
    description: "Learn to navigate and use Nuvra AI, including dashboards, features, and user tools",
    icon: Monitor,
    articleCount: 10,
    color: "bg-purple-500",
  },
  {
    id: "troubleshooting",
    title: "Troubleshooting",
    description: "Get help with Nuvra AI issues — errors, failed requests, and debugging tips",
    icon: Bug,
    articleCount: 9,
    color: "bg-red-500",
  },
  {
    id: "api",
    title: "Working with AI API",
    description: "Explore guides on using Nuvra AI's APIs, AI models — from setup to integration",
    icon: Code,
    articleCount: 18,
    color: "bg-indigo-500",
  },
];

const popularArticles = [
  {
    title: "How to get started with Nuvra AI",
    category: "General Information",
    readTime: "5 min",
    views: 15420,
  },
  {
    title: "Managing your API keys securely",
    category: "Platform Usage",
    readTime: "3 min",
    views: 12350,
  },
  {
    title: "Understanding token usage and billing",
    category: "Payments and Pricing",
    readTime: "7 min", 
    views: 9870,
  },
  {
    title: "Troubleshooting common API errors",
    category: "Troubleshooting",
    readTime: "10 min",
    views: 8240,
  },
  {
    title: "Best practices for production deployment",
    category: "Working with AI API",
    readTime: "12 min",
    views: 7120,
  },
];

const contactMethods = [
  {
    title: "Live Chat",
    description: "Get instant help from our support team",
    icon: MessageCircle,
    availability: "24/7",
    responseTime: "< 1 min",
    color: "bg-green-500",
  },
  {
    title: "Email Support",
    description: "Send us a detailed message about your issue",
    icon: Mail,
    availability: "24/7",
    responseTime: "< 4 hours",
    color: "bg-blue-500",
  },
  {
    title: "Phone Support",
    description: "Talk directly with our technical experts",
    icon: Phone,
    availability: "Business hours",
    responseTime: "Immediate",
    color: "bg-purple-500",
  },
];

export default function Help() {
  const [searchQuery, setSearchQuery] = useState("");
  const [ticketSubject, setTicketSubject] = useState("");
  const [ticketCategory, setTicketCategory] = useState("");
  const [ticketMessage, setTicketMessage] = useState("");
  const [ticketPriority, setTicketPriority] = useState("medium");

  const handleSubmitTicket = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle ticket submission
    console.log({
      subject: ticketSubject,
      category: ticketCategory,
      message: ticketMessage,
      priority: ticketPriority,
    });
    // Reset form
    setTicketSubject("");
    setTicketCategory("");
    setTicketMessage("");
    setTicketPriority("medium");
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center mx-auto mb-6">
            <HelpCircle className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Hello, how can we help?
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Find answers, guides, and solutions to your questions in our knowledge base
          </p>

          {/* Search */}
          <div className="max-w-lg mx-auto">
            <div className="relative">
              <Search className="w-5 h-5 absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search the knowledge base"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 py-4 text-lg"
                data-testid="help-search"
              />
              <Button
                className="absolute right-2 top-2"
                data-testid="search-button"
              >
                Search
              </Button>
            </div>
          </div>
        </div>

        {/* Help Categories */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {helpCategories.map((category) => (
            <Card
              key={category.id}
              className="hover:shadow-lg transition-all cursor-pointer group animate-fade-in glass-card"
              data-testid={`help-category-${category.id}`}
            >
              <CardContent className="p-8 text-center">
                <div className={`w-16 h-16 ${category.color} rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                  <category.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {category.title}
                </h3>
                <p className="text-muted-foreground mb-4 text-sm">
                  {category.description}
                </p>
                <div className="flex items-center justify-center text-xs text-muted-foreground">
                  <span>{category.articleCount} articles</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Popular Articles */}
        <Card className="glass-card mb-16">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center">
              <CheckCircle className="w-6 h-6 mr-2 text-green-500" />
              Popular Articles
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {popularArticles.map((article, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 rounded-lg border border-border hover:bg-accent/50 transition-colors cursor-pointer group"
                  data-testid={`popular-article-${index}`}
                >
                  <div className="flex-1">
                    <h4 className="font-semibold text-foreground mb-1 group-hover:text-primary transition-colors">
                      {article.title}
                    </h4>
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                      <Badge variant="outline" className="text-xs">
                        {article.category}
                      </Badge>
                      <span className="flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {article.readTime}
                      </span>
                      <span>{article.views.toLocaleString()} views</span>
                    </div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Contact Support */}
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Contact Methods */}
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-6">
              Need More Help?
            </h2>
            <p className="text-muted-foreground mb-8">
              Can't find what you're looking for? Our support team is here to help you 24/7.
            </p>

            <div className="space-y-6">
              {contactMethods.map((method, index) => (
                <Card
                  key={index}
                  className="hover:shadow-md transition-all cursor-pointer group"
                  data-testid={`contact-method-${index}`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className={`w-12 h-12 ${method.color} rounded-lg flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                        <method.icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg mb-1 group-hover:text-primary transition-colors">
                          {method.title}
                        </h3>
                        <p className="text-muted-foreground text-sm mb-3">
                          {method.description}
                        </p>
                        <div className="flex items-center space-x-4 text-xs">
                          <div className="flex items-center">
                            <Clock className="w-3 h-3 mr-1 text-green-500" />
                            <span className="text-muted-foreground">
                              {method.availability}
                            </span>
                          </div>
                          <div className="flex items-center">
                            <AlertCircle className="w-3 h-3 mr-1 text-blue-500" />
                            <span className="text-muted-foreground">
                              {method.responseTime}
                            </span>
                          </div>
                        </div>
                      </div>
                      <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Support Ticket Form */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-2xl">Submit a Support Ticket</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitTicket} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Subject *
                  </label>
                  <Input
                    value={ticketSubject}
                    onChange={(e) => setTicketSubject(e.target.value)}
                    placeholder="Briefly describe your issue"
                    required
                    data-testid="ticket-subject"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Category *
                  </label>
                  <Select value={ticketCategory} onValueChange={setTicketCategory}>
                    <SelectTrigger data-testid="ticket-category">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {helpCategories.map((category) => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.title}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Priority
                  </label>
                  <Select value={ticketPriority} onValueChange={setTicketPriority}>
                    <SelectTrigger data-testid="ticket-priority">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low - General question</SelectItem>
                      <SelectItem value="medium">Medium - Standard issue</SelectItem>
                      <SelectItem value="high">High - Urgent problem</SelectItem>
                      <SelectItem value="critical">Critical - Service down</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Message *
                  </label>
                  <Textarea
                    value={ticketMessage}
                    onChange={(e) => setTicketMessage(e.target.value)}
                    placeholder="Provide detailed information about your issue, including any error messages or steps to reproduce the problem"
                    rows={6}
                    required
                    data-testid="ticket-message"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={!ticketSubject || !ticketCategory || !ticketMessage}
                  data-testid="submit-ticket"
                >
                  Submit Ticket
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Status & Updates */}
        <Card className="glass-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl">System Status</CardTitle>
              <Badge className="bg-green-100 text-green-800">
                <CheckCircle className="w-3 h-3 mr-1" />
                All Systems Operational
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold mb-1">API Services</h3>
                <p className="text-sm text-green-600">Operational</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold mb-1">Dashboard</h3>
                <p className="text-sm text-green-600">Operational</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold mb-1">Billing</h3>
                <p className="text-sm text-green-600">Operational</p>
              </div>
            </div>
            <div className="text-center mt-6">
              <Button variant="outline" asChild data-testid="status-page">
                <Link href="/status">
                  View Full Status Page <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
