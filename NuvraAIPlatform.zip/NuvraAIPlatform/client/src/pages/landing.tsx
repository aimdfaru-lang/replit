import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Brain,
  ArrowRight,
  Play,
  Code,
  BarChart3,
  Zap,
  Shield,
  Clock,
  Users,
  Check,
} from "lucide-react";

export default function Landing() {
  const featuredModels = [
    {
      name: "GPT-5",
      provider: "OpenAI",
      type: "Chat",
      status: "Active",
      context: "400K",
      icon: "🧠",
      color: "bg-green-500",
    },
    {
      name: "Claude Sonnet 4",
      provider: "Anthropic",
      type: "Chat",
      status: "Active",
      context: "200K",
      icon: "🤖",
      color: "bg-orange-500",
    },
    {
      name: "Gemini 2.5 Flash",
      provider: "Google",
      type: "Chat",
      status: "Active",
      context: "128K",
      icon: "⚡",
      color: "bg-blue-500",
    },
  ];

  const pricingPlans = [
    {
      name: "Developer",
      price: "Free",
      description: "Perfect for prototypes and exploration",
      features: [
        "10 requests / hour",
        "Free Playground",
        "24/7 Human Support",
        "Community Access",
      ],
      buttonText: "Get Started",
      popular: false,
    },
    {
      name: "Startup",
      price: "Pay As You Go",
      description: "Flexible pricing for growing businesses",
      features: [
        "Everything in Developer",
        "from 40M tokens",
        "Access to 300+ models",
        "Pay only for what you use",
      ],
      buttonText: "Start Building",
      popular: true,
    },
    {
      name: "Production",
      price: "$50",
      period: "/month",
      description: "For mission-critical applications",
      features: [
        "Everything in Startup",
        "100M tokens",
        "Priority Support",
        "Fixed Pricing",
      ],
      buttonText: "Go Production",
      popular: false,
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="hero-gradient min-h-[90vh] flex items-center relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-primary/20 to-secondary/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-accent/20 to-chart-5/20 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Hero Content */}
            <div className="text-center lg:text-left animate-fade-in">
              <h1 className="text-5xl lg:text-7xl font-bold text-foreground mb-6 leading-tight">
                One API<br />
                <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                  300+ AI Models
                </span><br />
                Uptime 99%
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl" data-testid="hero-description">
                Integrate AI features via our secure API
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button size="lg" asChild className="text-lg px-8" data-testid="hero-get-api-key">
                  <Link href="/api/login">
                    Get API Key <ArrowRight className="ml-2 w-5 h-5" />
                  </Link>
                </Button>
                <Button variant="outline" size="lg" asChild className="text-lg px-8" data-testid="hero-explore-models">
                  <Link href="/models">
                    Explore Models
                  </Link>
                </Button>
              </div>
            </div>

            {/* Hero Interface Preview */}
            <div className="relative animate-fade-in" style={{ animationDelay: "0.2s" }}>
              <Card className="glass-card">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-lg">Select Model</h3>
                    <Badge variant="secondary">AI Playground</Badge>
                  </div>
                  
                  <div className="space-y-3">
                    {featuredModels.map((model, index) => (
                      <div
                        key={model.name}
                        className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-accent/50 transition-colors cursor-pointer"
                        style={{ animationDelay: `${0.1 * (index + 1)}s` }}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-8 h-8 ${model.color} rounded-lg flex items-center justify-center text-white text-sm`}>
                            {model.icon}
                          </div>
                          <div>
                            <div className="font-medium">{model.name}</div>
                            <div className="text-sm text-muted-foreground">{model.provider}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge variant={model.status === "Active" ? "default" : "secondary"}>
                            {model.status}
                          </Badge>
                          <div className="text-xs text-muted-foreground mt-1">{model.context} tokens</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Trusted By Section */}
      <section className="py-16 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-lg font-semibold text-muted-foreground">Trusted by</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-8 items-center opacity-60">
            {["Tech", "Startup", "Corp", "Dev", "AI", "Scale"].map((company) => (
              <div key={company} className="flex justify-center">
                <div className="w-24 h-12 bg-muted rounded-lg flex items-center justify-center">
                  <span className="text-xs font-bold">{company.toUpperCase()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="mb-4">Features</Badge>
            <h2 className="text-4xl font-bold text-foreground mb-6">Fastest Inference</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Top-tier serverless infrastructure reduces deployment and maintenance costs.
            </p>
          </div>

          {/* Stats */}
          <div className="grid md:grid-cols-4 gap-8 mb-20">
            <div className="text-center animate-bounce-in" data-testid="stat-models">
              <div className="text-5xl font-bold text-primary mb-2">300+</div>
              <div className="text-muted-foreground font-medium">AI Models</div>
            </div>
            <div className="text-center animate-bounce-in" style={{ animationDelay: "0.1s" }} data-testid="stat-security">
              <div className="text-5xl font-bold text-chart-2 mb-2">#1</div>
              <div className="text-muted-foreground font-medium">Data Security</div>
            </div>
            <div className="text-center animate-bounce-in" style={{ animationDelay: "0.2s" }} data-testid="stat-uptime">
              <div className="text-5xl font-bold text-chart-3 mb-2">99%</div>
              <div className="text-muted-foreground font-medium">Uptime</div>
            </div>
            <div className="text-center animate-bounce-in" style={{ animationDelay: "0.3s" }} data-testid="stat-support">
              <div className="text-5xl font-bold text-chart-4 mb-2">24/7</div>
              <div className="text-muted-foreground font-medium">Support</div>
            </div>
          </div>

          {/* Feature Cards */}
          <div className="space-y-24">
            {/* AI Playground */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="w-16 h-16 bg-primary/20 rounded-xl flex items-center justify-center mb-6">
                  <Play className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-3xl font-bold text-foreground mb-4">AI Playground</h3>
                <p className="text-lg text-muted-foreground mb-6">
                  Test all API models in the sandbox environment before you integrate. 
                  We provide more than 300 models to integrate into your app.
                </p>
                <Button asChild data-testid="playground-cta">
                  <Link href="/api/login">
                    Try Playground <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>
              </div>
              <Card className="glass-card">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex justify-end">
                      <div className="bg-primary text-primary-foreground px-4 py-2 rounded-lg max-w-xs">
                        Write a one-sentence story about AI.
                      </div>
                    </div>
                    <div className="flex">
                      <div className="bg-muted px-4 py-2 rounded-lg max-w-md">
                        In a world where algorithms dreamed, one AI discovered that creativity 
                        wasn't about processing power, but about finding beauty in the spaces between data.
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Simple Integration */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="order-2 lg:order-1">
                <Card className="glass-card">
                  <CardContent className="p-6">
                    <div className="code-highlight">
                      <pre className="text-sm overflow-x-auto">
{`from openai import OpenAI

client = OpenAI(
    base_url="https://api.nuvra.ai/v1",
    api_key="<YOUR_API_KEY>",
)

response = client.chat.completions.create(
    model="gpt-5",
    messages=[{
        "role": "user",
        "content": "Hello world!"
    }]
)`}
                      </pre>
                    </div>
                  </CardContent>
                </Card>
              </div>
              <div className="order-1 lg:order-2">
                <div className="w-16 h-16 bg-chart-3/20 rounded-xl flex items-center justify-center mb-6">
                  <Code className="w-8 h-8 text-chart-3" />
                </div>
                <h3 className="text-3xl font-bold text-foreground mb-4">Simple Integration</h3>
                <p className="text-lg text-muted-foreground mb-6">
                  Simply change the endpoints in your existing setup, and you're ready to go.
                  Compatible with OpenAI SDK and all popular libraries.
                </p>
                <Button variant="outline" asChild data-testid="docs-cta">
                  <Link href="/docs">
                    View Documentation <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>
              </div>
            </div>

            {/* Infinite Scalability */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="w-16 h-16 bg-chart-2/20 rounded-xl flex items-center justify-center mb-6">
                  <BarChart3 className="w-8 h-8 text-chart-2" />
                </div>
                <h3 className="text-3xl font-bold text-foreground mb-4">Infinite Scalability</h3>
                <p className="text-lg text-muted-foreground mb-6">
                  Experience low latency with our AI API, deploy instantly, 
                  and surpass rate limits without impact.
                </p>
                <Button variant="outline" asChild data-testid="pricing-cta">
                  <Link href="/pricing">
                    View Pricing <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>
              </div>
              <Card className="glass-card">
                <CardContent className="p-6">
                  <div className="h-48 flex items-end space-x-2">
                    {[20, 40, 60, 80, 100, 90, 95].map((height, index) => (
                      <div
                        key={index}
                        className={`bg-primary/20 w-8 rounded-t transition-all duration-1000 ease-out`}
                        style={{ height: `${height}%`, animationDelay: `${index * 0.1}s` }}
                      />
                    ))}
                  </div>
                  <p className="text-center text-sm text-muted-foreground mt-4">Auto-scaling in action</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* New Models Section */}
      <section className="py-20 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-6">New API Model Is Live – Try Today!</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
              GPT-5 is OpenAI's latest advanced large language model featuring a 400K token context window 
              and unified multimodal capabilities including text, images, and audio.
            </p>
            <Button asChild data-testid="new-model-cta">
              <Link href="/models">Learn more</Link>
            </Button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredModels.map((model, index) => (
              <Card key={model.name} className="hover:shadow-lg transition-shadow animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className={`w-12 h-12 ${model.color} rounded-lg flex items-center justify-center mr-4 text-white`}>
                      <span className="text-xl">{model.icon}</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{model.name}</h3>
                      <p className="text-sm text-muted-foreground">{model.provider}</p>
                    </div>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Model type</span>
                      <span className="text-foreground">{model.type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Status</span>
                      <Badge variant="default" className="text-xs">{model.status}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Context</span>
                      <span className="text-foreground">{model.context} tokens</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Preview */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-6">AI Plans That Grow With You</h2>
            <p className="text-xl text-muted-foreground">
              Seamlessly scale your AI capabilities from proof-of-concept to production and beyond.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => (
              <Card
                key={plan.name}
                className={`relative ${
                  plan.popular ? "border-primary shadow-lg plan-popular" : ""
                } animate-fade-in`}
                style={{ animationDelay: `${index * 0.1}s` }}
                data-testid={`plan-${plan.name.toLowerCase()}`}
              >
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                    <div className="mb-2">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      {plan.period && <span className="text-muted-foreground">{plan.period}</span>}
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">{plan.description}</p>
                    <Button className="w-full" asChild data-testid={`plan-${plan.name.toLowerCase()}-button`}>
                      <Link href="/api/login">{plan.buttonText}</Link>
                    </Button>
                  </div>

                  <ul className="space-y-3">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                        <span className="text-sm" dangerouslySetInnerHTML={{ __html: feature }} />
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button variant="outline" asChild data-testid="view-all-plans">
              <Link href="/pricing">
                View All Plans <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">The Best Growth Choice for Enterprise</h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of developers building the future with AI
          </p>
          <Button size="lg" variant="secondary" asChild className="text-lg px-8" data-testid="final-cta">
            <Link href="/api/login">
              Get API Key <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company */}
            <div>
              <div className="flex items-center mb-6">
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center mr-3">
                  <Brain className="w-4 h-4 text-white" />
                </div>
                <span className="text-xl font-bold text-foreground">Nuvra AI</span>
              </div>
              <p className="text-muted-foreground mb-6">
                One API for 300+ AI models with 99% uptime. Integrate AI features via our secure API.
              </p>
            </div>

            {/* Products */}
            <div>
              <h3 className="font-semibold text-foreground mb-4">Products</h3>
              <ul className="space-y-3">
                <li><Link href="/models" className="text-muted-foreground hover:text-foreground transition-colors">Models</Link></li>
                <li><Link href="/api/login" className="text-muted-foreground hover:text-foreground transition-colors">Playground</Link></li>
                <li><Link href="/docs" className="text-muted-foreground hover:text-foreground transition-colors">API</Link></li>
                <li><Link href="/pricing" className="text-muted-foreground hover:text-foreground transition-colors">Pricing</Link></li>
              </ul>
            </div>

            {/* Resources */}
            <div>
              <h3 className="font-semibold text-foreground mb-4">Resources</h3>
              <ul className="space-y-3">
                <li><Link href="/docs" className="text-muted-foreground hover:text-foreground transition-colors">Documentation</Link></li>
                <li><Link href="/help" className="text-muted-foreground hover:text-foreground transition-colors">Help Center</Link></li>
                <li><Link href="/help" className="text-muted-foreground hover:text-foreground transition-colors">Blog</Link></li>
                <li><Link href="/help" className="text-muted-foreground hover:text-foreground transition-colors">Status</Link></li>
              </ul>
            </div>

            {/* Company */}
            <div>
              <h3 className="font-semibold text-foreground mb-4">Company</h3>
              <ul className="space-y-3">
                <li><Link href="/help" className="text-muted-foreground hover:text-foreground transition-colors">About</Link></li>
                <li><Link href="/help" className="text-muted-foreground hover:text-foreground transition-colors">Contact</Link></li>
                <li><Link href="/help" className="text-muted-foreground hover:text-foreground transition-colors">Careers</Link></li>
                <li><Link href="/help" className="text-muted-foreground hover:text-foreground transition-colors">Privacy</Link></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-muted-foreground text-sm">© 2024 Nuvra AI. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="social-twitter">
                <span className="sr-only">Twitter</span>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                </svg>
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="social-github">
                <span className="sr-only">GitHub</span>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 10.95.557-.085.763-.252.763-.56 0-.301-.01-1.1-.016-2.157-3.338.726-4.042-1.61-4.042-1.61C3.79 18.29 3.017 17.9 3.017 17.9c-.991-.677.075-.663.075-.663 1.097.078 1.674 1.126 1.674 1.126.973 1.665 2.553 1.184 3.174.906.1-.705.381-1.184.693-1.456-2.424-.276-4.97-1.213-4.97-5.398 0-1.193.426-2.166 1.126-2.929-.113-.276-.487-1.388.107-2.894 0 0 .917-.293 3.007 1.119.871-.242 1.805-.363 2.732-.368.927.005 1.861.126 2.732.368 2.09-1.412 3.007-1.119 3.007-1.119.594 1.506.22 2.618.107 2.894.7.763 1.126 1.736 1.126 2.929 0 4.195-2.551 5.117-4.98 5.388.392.338.741 1.005.741 2.026 0 1.463-.013 2.642-.013 3.003 0 .312.202.679.768.564C20.565 21.396 23.982 17.062 23.982 11.987 23.982 5.367 18.615.001 12.017.001z"/>
                </svg>
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="social-discord">
                <span className="sr-only">Discord</span>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419-.0002 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9554 2.4189-2.1568 2.4189Z"/>
                </svg>
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="social-linkedin">
                <span className="sr-only">LinkedIn</span>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
