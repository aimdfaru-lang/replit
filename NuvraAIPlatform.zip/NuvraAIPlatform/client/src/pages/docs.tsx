import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Search,
  BookOpen,
  Code,
  Zap,
  ArrowRight,
  Copy,
  ExternalLink,
  MessageSquare,
  Image as ImageIcon,
  Mic,
  FileText,
  Wrench,
  Lightbulb,
} from "lucide-react";

const quickStartSteps = [
  {
    title: "Get Your API Key",
    description: "Sign up for a Nuvra AI account and generate your first API key from the dashboard.",
    action: "Get API Key",
    href: "/api/login",
  },
  {
    title: "Install the SDK",
    description: "Install our official SDK or use any OpenAI-compatible library.",
    code: "npm install openai",
  },
  {
    title: "Make Your First Request",
    description: "Start using AI models with just a few lines of code.",
    code: `from openai import OpenAI

client = OpenAI(
    base_url="https://api.nuvra.ai/v1",
    api_key="your-api-key-here"
)

response = client.chat.completions.create(
    model="gpt-5",
    messages=[{
        "role": "user", 
        "content": "Hello, world!"
    }]
)

print(response.choices[0].message.content)`,
  },
];

const modelCategories = [
  {
    id: "chat",
    name: "Chat Models",
    icon: MessageSquare,
    color: "bg-blue-500",
    models: ["GPT-5", "Claude Sonnet 4", "Gemini 2.5 Flash"],
    description: "Conversational AI models for chat, Q&A, and text generation",
  },
  {
    id: "code",
    name: "Code Generation",
    icon: Code,
    color: "bg-green-500", 
    models: ["Grok Code Fast 1", "DeepSeek V3.1", "GPT-5"],
    description: "Specialized models for code generation, review, and debugging",
  },
  {
    id: "image",
    name: "Image Models",
    icon: ImageIcon,
    color: "bg-purple-500",
    models: ["DALL-E 3", "Midjourney", "Stable Diffusion"],
    description: "Generate, edit, and analyze images with AI",
  },
  {
    id: "voice",
    name: "Voice & Audio",
    icon: Mic,
    color: "bg-orange-500",
    models: ["Whisper", "ElevenLabs", "Azure Speech"],
    description: "Speech-to-text, text-to-speech, and audio processing",
  },
];

const apiEndpoints = [
  {
    method: "POST",
    path: "/v1/chat/completions",
    description: "Create a chat completion",
    popular: true,
  },
  {
    method: "POST", 
    path: "/v1/images/generations",
    description: "Generate images from text",
  },
  {
    method: "POST",
    path: "/v1/audio/transcriptions", 
    description: "Transcribe audio to text",
  },
  {
    method: "POST",
    path: "/v1/embeddings",
    description: "Create embeddings",
  },
];

const guides = [
  {
    title: "Building a Chatbot",
    description: "Learn how to create an intelligent chatbot using our chat completion API",
    difficulty: "Beginner",
    time: "15 min",
    category: "Tutorial",
  },
  {
    title: "Image Processing Pipeline",
    description: "Process and generate images with our computer vision models",
    difficulty: "Intermediate", 
    time: "30 min",
    category: "Tutorial",
  },
  {
    title: "Voice Assistant Integration",
    description: "Build voice-powered applications with speech recognition and synthesis",
    difficulty: "Advanced",
    time: "45 min",
    category: "Tutorial",
  },
  {
    title: "Rate Limiting & Best Practices",
    description: "Optimize your API usage and handle rate limits effectively",
    difficulty: "Intermediate",
    time: "10 min", 
    category: "Guide",
  },
  {
    title: "Production Deployment",
    description: "Deploy AI-powered applications to production with confidence",
    difficulty: "Advanced",
    time: "60 min",
    category: "Guide",
  },
  {
    title: "Error Handling Strategies", 
    description: "Robust error handling patterns for AI applications",
    difficulty: "Intermediate",
    time: "20 min",
    category: "Guide",
  },
];

export default function Docs() {
  const [searchQuery, setSearchQuery] = useState("");

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const filteredGuides = guides.filter(
    (guide) =>
      guide.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      guide.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-4">Documentation</Badge>
          <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Nuvra AI Documentation
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Learn how to get started with the Nuvra AI API. Complete guides, 
            references, and examples to help you integrate AI into your applications.
          </p>

          {/* Search */}
          <div className="max-w-lg mx-auto">
            <div className="relative">
              <Search className="w-5 h-5 absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search documentation..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 py-3 text-lg"
                data-testid="docs-search"
              />
            </div>
          </div>
        </div>

        {/* Quick Start */}
        <Card className="glass-card mb-12">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Zap className="w-6 h-6 text-primary" />
              <CardTitle className="text-2xl">Quick Start</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid lg:grid-cols-3 gap-8">
              {quickStartSteps.map((step, index) => (
                <div key={index} className="relative">
                  <div className="flex items-center mb-4">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold mr-3">
                      {index + 1}
                    </div>
                    <h3 className="text-lg font-semibold">{step.title}</h3>
                  </div>
                  <p className="text-muted-foreground mb-4">
                    {step.description}
                  </p>
                  
                  {step.action && (
                    <Button asChild data-testid={`quick-start-${index}`}>
                      <Link href={step.href!}>
                        {step.action} <ArrowRight className="ml-2 w-4 h-4" />
                      </Link>
                    </Button>
                  )}

                  {step.code && (
                    <div className="relative bg-muted/50 rounded-lg p-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={() => copyToClipboard(step.code!)}
                        data-testid={`copy-code-${index}`}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      <pre className="text-sm overflow-x-auto pr-12">
                        <code>{step.code}</code>
                      </pre>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Model Categories */}
        <Card className="glass-card mb-12">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center">
              <BookOpen className="w-6 h-6 mr-2" />
              Browse Models
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-6">
              Explore our collection of 300+ AI models across different categories
            </p>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {modelCategories.map((category) => (
                <Card
                  key={category.id}
                  className="hover:shadow-md transition-all cursor-pointer group"
                  data-testid={`model-category-${category.id}`}
                >
                  <CardContent className="p-6 text-center">
                    <div className={`w-12 h-12 ${category.color} rounded-lg flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                      <category.icon className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-semibold text-lg mb-2">{category.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      {category.description}
                    </p>
                    <div className="text-xs text-muted-foreground">
                      {category.models.slice(0, 2).join(", ")}
                      {category.models.length > 2 && "..."}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* API Reference & SDKs */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2" />
                API Reference
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-6">
                Complete reference for all API endpoints and parameters
              </p>
              <div className="space-y-3">
                {apiEndpoints.map((endpoint, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-accent/50 transition-colors cursor-pointer"
                    data-testid={`api-endpoint-${index}`}
                  >
                    <div className="flex items-center space-x-3">
                      <Badge variant={endpoint.method === "POST" ? "default" : "secondary"}>
                        {endpoint.method}
                      </Badge>
                      <div>
                        <code className="text-sm font-mono">{endpoint.path}</code>
                        <p className="text-xs text-muted-foreground">
                          {endpoint.description}
                        </p>
                      </div>
                    </div>
                    {endpoint.popular && (
                      <Badge variant="outline" className="text-xs">
                        Popular
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Wrench className="w-5 h-5 mr-2" />
                SDKs & Libraries
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-6">
                Official libraries for popular programming languages
              </p>
              <div className="space-y-4">
                {[
                  { name: "Python SDK", desc: "pip install openai", popular: true },
                  { name: "Node.js SDK", desc: "npm install openai", popular: true },
                  { name: "Go SDK", desc: "go get github.com/openai/openai-go" },
                  { name: "REST API", desc: "Direct HTTP requests" },
                ].map((sdk, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-accent/50 transition-colors cursor-pointer"
                    data-testid={`sdk-${index}`}
                  >
                    <div>
                      <div className="font-medium flex items-center">
                        {sdk.name}
                        {sdk.popular && (
                          <Badge variant="secondary" className="ml-2 text-xs">
                            Popular
                          </Badge>
                        )}
                      </div>
                      <code className="text-xs text-muted-foreground">{sdk.desc}</code>
                    </div>
                    <ExternalLink className="w-4 h-4 text-muted-foreground" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Guides & Tutorials */}
        <Card className="glass-card">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl flex items-center">
                <Lightbulb className="w-6 h-6 mr-2" />
                Guides & Tutorials
              </CardTitle>
              <div className="text-sm text-muted-foreground">
                {filteredGuides.length} guides
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="tutorial">Tutorials</TabsTrigger>
                <TabsTrigger value="guide">Guides</TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="space-y-4">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredGuides.map((guide, index) => (
                    <Card
                      key={index}
                      className="hover:shadow-md transition-all cursor-pointer group"
                      data-testid={`guide-${index}`}
                    >
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-3">
                          <Badge variant="outline" className="text-xs">
                            {guide.category}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {guide.time}
                          </span>
                        </div>
                        <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                          {guide.title}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          {guide.description}
                        </p>
                        <div className="flex items-center justify-between">
                          <Badge
                            variant="secondary"
                            className={`text-xs ${
                              guide.difficulty === "Beginner"
                                ? "bg-green-100 text-green-800"
                                : guide.difficulty === "Intermediate"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                            }`}
                          >
                            {guide.difficulty}
                          </Badge>
                          <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="tutorial" className="space-y-4">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredGuides
                    .filter((guide) => guide.category === "Tutorial")
                    .map((guide, index) => (
                      <Card
                        key={index}
                        className="hover:shadow-md transition-all cursor-pointer group"
                      >
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between mb-3">
                            <Badge variant="outline" className="text-xs">
                              {guide.category}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {guide.time}
                            </span>
                          </div>
                          <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                            {guide.title}
                          </h3>
                          <p className="text-sm text-muted-foreground mb-4">
                            {guide.description}
                          </p>
                          <div className="flex items-center justify-between">
                            <Badge
                              variant="secondary"
                              className={`text-xs ${
                                guide.difficulty === "Beginner"
                                  ? "bg-green-100 text-green-800"
                                  : guide.difficulty === "Intermediate"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-red-100 text-red-800"
                              }`}
                            >
                              {guide.difficulty}
                            </Badge>
                            <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              </TabsContent>

              <TabsContent value="guide" className="space-y-4">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredGuides
                    .filter((guide) => guide.category === "Guide")
                    .map((guide, index) => (
                      <Card
                        key={index}
                        className="hover:shadow-md transition-all cursor-pointer group"
                      >
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between mb-3">
                            <Badge variant="outline" className="text-xs">
                              {guide.category}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {guide.time}
                            </span>
                          </div>
                          <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                            {guide.title}
                          </h3>
                          <p className="text-sm text-muted-foreground mb-4">
                            {guide.description}
                          </p>
                          <div className="flex items-center justify-between">
                            <Badge
                              variant="secondary"
                              className={`text-xs ${
                                guide.difficulty === "Beginner"
                                  ? "bg-green-100 text-green-800"
                                  : guide.difficulty === "Intermediate"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-red-100 text-red-800"
                              }`}
                            >
                              {guide.difficulty}
                            </Badge>
                            <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
