import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Send,
  Bot,
  User,
  Trash2,
  Settings,
  Zap,
  Copy,
  Download,
  RefreshCw,
} from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
}

interface PlaygroundSettings {
  temperature: number;
  maxTokens: number;
  topP: number;
}

export default function Playground() {
  const { toast } = useToast();
  const [selectedModel, setSelectedModel] = useState("gpt-5");
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [settings, setSettings] = useState<PlaygroundSettings>({
    temperature: 0.7,
    maxTokens: 1000,
    topP: 0.9,
  });
  const [showSettings, setShowSettings] = useState(false);

  // Fetch available models
  interface Model {
    id: string;
    name: string;
    provider: string;
    type: string;
    context: string;
    status: string;
    description: string;
  }

  const { data: models = [], error: modelsError } = useQuery<Model[]>({
    queryKey: ["/api/models"],
  });

  // Handle models fetch error
  if (modelsError) {
    if (isUnauthorizedError(modelsError)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    } else {
      toast({
        title: "Error",
        description: "Failed to load models",
        variant: "destructive",
      });
    }
  }

  // Send message mutation
  const sendMessage = useMutation({
    mutationFn: async (messageContent: string) => {
      const newMessages = [
        ...messages,
        {
          id: Date.now().toString(),
          role: "user" as const,
          content: messageContent,
          timestamp: new Date(),
        },
      ];

      const response = await apiRequest("POST", "/api/v1/chat/completions", {
        model: selectedModel,
        messages: newMessages.map((msg) => ({
          role: msg.role,
          content: msg.content,
        })),
        temperature: settings.temperature,
        max_tokens: settings.maxTokens,
        top_p: settings.topP,
      });

      return await response.json();
    },
    onSuccess: (data) => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data.choices[0].message.content,
        timestamp: new Date(),
      };

      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          role: "user",
          content: inputMessage,
          timestamp: new Date(),
        },
        assistantMessage,
      ]);

      setInputMessage("");

      toast({
        title: "Message sent",
        description: `Response generated using ${selectedModel}`,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      console.error("Chat error:", error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || sendMessage.isPending) return;

    sendMessage.mutate(inputMessage.trim());
  };

  const clearChat = () => {
    setMessages([]);
    toast({
      title: "Chat cleared",
      description: "All messages have been removed",
    });
  };

  const copyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
    toast({
      title: "Copied",
      description: "Message copied to clipboard",
    });
  };

  const exportChat = () => {
    const chatData = {
      model: selectedModel,
      messages,
      settings,
      exportedAt: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(chatData, null, 2)], {
      type: "application/json",
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `nuvra-ai-chat-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Chat exported",
      description: "Chat history has been downloaded",
    });
  };

  const selectedModelData = models.find((m: any) => m.id === selectedModel);

  return (
    <div className="h-full flex">
      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="border-b border-border p-4 bg-card">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Select value={selectedModel} onValueChange={setSelectedModel}>
                <SelectTrigger className="w-64" data-testid="model-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {models.map((model: any) => (
                    <SelectItem key={model.id} value={model.id}>
                      <div className="flex items-center space-x-2">
                        <span>{model.name}</span>
                        <Badge variant="outline" className="text-xs">
                          {model.provider}
                        </Badge>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedModelData && (
                <Badge variant="default" className="text-xs">
                  {selectedModelData.status === "active" ? "Active" : "Inactive"}
                </Badge>
              )}
            </div>

            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowSettings(!showSettings)}
                data-testid="toggle-settings"
              >
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={exportChat}
                disabled={messages.length === 0}
                data-testid="export-chat"
              >
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={clearChat}
                disabled={messages.length === 0}
                data-testid="clear-chat"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear
              </Button>
            </div>
          </div>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-6 max-w-4xl mx-auto">
            {messages.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Bot className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Start a conversation</h3>
                <p className="text-muted-foreground">
                  Choose a model and type your message to get started with the AI playground.
                </p>
              </div>
            ) : (
              messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${
                    message.role === "user" ? "justify-end" : "justify-start"
                  } animate-fade-in`}
                  data-testid={`message-${message.id}`}
                >
                  <div
                    className={`flex items-start space-x-3 max-w-[80%] ${
                      message.role === "user" ? "flex-row-reverse space-x-reverse" : ""
                    }`}
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        message.role === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {message.role === "user" ? (
                        <User className="w-4 h-4" />
                      ) : (
                        <Bot className="w-4 h-4" />
                      )}
                    </div>

                    <div
                      className={`rounded-lg p-4 ${
                        message.role === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted"
                      }`}
                    >
                      <div className="text-sm font-medium mb-1">
                        {message.role === "user"
                          ? "You"
                          : selectedModelData?.name || "Assistant"}
                      </div>
                      <div className="whitespace-pre-wrap">{message.content}</div>
                      <div className="flex items-center justify-between mt-2 pt-2 border-t border-border/20">
                        <span className="text-xs opacity-70">
                          {message.timestamp.toLocaleTimeString()}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyMessage(message.content)}
                          className="h-6 w-6 p-0"
                          data-testid={`copy-message-${message.id}`}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}

            {sendMessage.isPending && (
              <div className="flex justify-start animate-fade-in">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  </div>
                  <div className="bg-muted rounded-lg p-4">
                    <div className="text-sm font-medium mb-1">
                      {selectedModelData?.name || "Assistant"}
                    </div>
                    <div className="text-muted-foreground">Thinking...</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="border-t border-border p-4 bg-card">
          <form onSubmit={handleSendMessage} className="max-w-4xl mx-auto">
            <div className="flex space-x-4">
              <Textarea
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 min-h-[60px] resize-none"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage(e);
                  }
                }}
                data-testid="message-input"
              />
              <Button
                type="submit"
                disabled={!inputMessage.trim() || sendMessage.isPending}
                className="px-6"
                data-testid="send-button"
              >
                {sendMessage.isPending ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
          </form>
        </div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div className="w-80 border-l border-border bg-card">
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold">Model Settings</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSettings(false)}
                data-testid="close-settings"
              >
                ×
              </Button>
            </div>

            <div className="space-y-6">
              {/* Model Info */}
              {selectedModelData && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">Current Model</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="text-sm">
                      <strong>{selectedModelData.name}</strong>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {selectedModelData.provider} • {selectedModelData.context}
                    </div>
                    <Badge
                      variant={selectedModelData.status === "active" ? "default" : "secondary"}
                      className="text-xs"
                    >
                      {selectedModelData.status}
                    </Badge>
                  </CardContent>
                </Card>
              )}

              {/* Temperature */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="temperature">Temperature</Label>
                  <span className="text-sm text-muted-foreground">
                    {settings.temperature}
                  </span>
                </div>
                <Slider
                  id="temperature"
                  min={0}
                  max={2}
                  step={0.1}
                  value={[settings.temperature]}
                  onValueChange={(value) =>
                    setSettings((prev) => ({ ...prev, temperature: value[0] }))
                  }
                  data-testid="temperature-slider"
                />
                <p className="text-xs text-muted-foreground">
                  Controls randomness. Lower values are more focused and deterministic.
                </p>
              </div>

              <Separator />

              {/* Max Tokens */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="maxTokens">Max Tokens</Label>
                  <span className="text-sm text-muted-foreground">
                    {settings.maxTokens}
                  </span>
                </div>
                <Slider
                  id="maxTokens"
                  min={1}
                  max={4000}
                  step={1}
                  value={[settings.maxTokens]}
                  onValueChange={(value) =>
                    setSettings((prev) => ({ ...prev, maxTokens: value[0] }))
                  }
                  data-testid="max-tokens-slider"
                />
                <p className="text-xs text-muted-foreground">
                  Maximum number of tokens to generate in the response.
                </p>
              </div>

              <Separator />

              {/* Top P */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label htmlFor="topP">Top P</Label>
                  <span className="text-sm text-muted-foreground">
                    {settings.topP}
                  </span>
                </div>
                <Slider
                  id="topP"
                  min={0}
                  max={1}
                  step={0.1}
                  value={[settings.topP]}
                  onValueChange={(value) =>
                    setSettings((prev) => ({ ...prev, topP: value[0] }))
                  }
                  data-testid="top-p-slider"
                />
                <p className="text-xs text-muted-foreground">
                  Controls diversity via nucleus sampling. Lower values are more focused.
                </p>
              </div>

              <Separator />

              {/* Reset Button */}
              <Button
                variant="outline"
                className="w-full"
                onClick={() =>
                  setSettings({
                    temperature: 0.7,
                    maxTokens: 1000,
                    topP: 0.9,
                  })
                }
                data-testid="reset-settings"
              >
                Reset to Defaults
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
