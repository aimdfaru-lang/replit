import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  CreditCard,
  Calendar,
  DollarSign,
  TrendingUp,
  Download,
  ExternalLink,
  AlertCircle,
  Crown,
  Zap,
  Shield,
} from "lucide-react";

interface BillingHistory {
  id: string;
  amount: string;
  status: string;
  description: string;
  billingPeriodStart: string;
  billingPeriodEnd: string;
  createdAt: string;
}

interface UsageStats {
  totalCost: number;
  totalTokens: number;
  totalRequests: number;
}

export default function Billing() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isUpdatePaymentOpen, setIsUpdatePaymentOpen] = useState(false);

  // Fetch billing history
  const { data: billingHistory = [], isLoading: historyLoading, error: historyError } = useQuery({
    queryKey: ["/api/billing/history"],
  }) as { data: BillingHistory[]; isLoading: boolean; error: any };

  // Handle history fetch error
  if (historyError && isUnauthorizedError(historyError)) {
    toast({
      title: "Unauthorized",
      description: "You are logged out. Logging in again...",
      variant: "destructive",
    });
    setTimeout(() => {
      window.location.href = "/api/login";
    }, 500);
  }

  // Fetch current usage stats
  const { data: stats, error: statsError } = useQuery({
    queryKey: ["/api/usage"],
  }) as { data: UsageStats | undefined; error: any };

  // Handle stats fetch error
  if (statsError && isUnauthorizedError(statsError)) {
    toast({
      title: "Unauthorized",
      description: "You are logged out. Logging in again...",
      variant: "destructive",
    });
    setTimeout(() => {
      window.location.href = "/api/login";
    }, 500);
  }

  const currentPlan = user?.plan || "developer";
  
  // Plan details
  const planDetails = {
    developer: {
      name: "Developer",
      price: 0,
      period: "month",
      tokensIncluded: 0,
      description: "Perfect for exploration and testing",
      features: ["10 requests/hour", "Community support", "Basic models"],
      color: "bg-gray-500",
    },
    startup: {
      name: "Startup", 
      price: 0,
      period: "usage",
      tokensIncluded: 40000000,
      description: "Pay only for what you use",
      features: ["Unlimited requests", "All models", "Email support"],
      color: "bg-blue-500",
    },
    production: {
      name: "Production",
      price: 50,
      period: "month",
      tokensIncluded: 100000000,
      description: "For mission-critical applications",
      features: ["100M tokens", "Priority support", "SLA guarantee"],
      color: "bg-purple-500",
    },
    scale: {
      name: "Scale",
      price: 200,
      period: "month", 
      tokensIncluded: 400000000,
      description: "High-volume applications",
      features: ["400M tokens", "Personal manager", "Phone support"],
      color: "bg-green-500",
    },
    crypto: {
      name: "Crypto",
      price: 100,
      period: "month",
      tokensIncluded: 200000000,
      description: "Pay with cryptocurrency",
      features: ["200M tokens", "Crypto payments", "Privacy focused"],
      color: "bg-orange-500",
    },
    enterprise: {
      name: "Enterprise",
      price: 0,
      period: "custom",
      tokensIncluded: 0,
      description: "Custom enterprise solutions",
      features: ["Custom pricing", "Dedicated servers", "White-label"],
      color: "bg-gold",
    },
  };

  const plan = planDetails[currentPlan as keyof typeof planDetails];
  
  // Calculate usage percentage
  const tokenUsage = stats?.totalTokens || 0;
  const usagePercentage = plan.tokensIncluded > 0 
    ? Math.min((tokenUsage / plan.tokensIncluded) * 100, 100)
    : 0;

  // Calculate overage
  const overageTokens = Math.max(tokenUsage - plan.tokensIncluded, 0);
  const overageCost = overageTokens * 0.000001; // $0.000001 per token overage

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    }
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  if (historyLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-48"></div>
          <div className="h-32 bg-muted rounded"></div>
          <div className="h-48 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Billing & Subscription</h2>
          <p className="text-muted-foreground">
            Manage your subscription, payment methods, and billing history
          </p>
        </div>
        <Button asChild data-testid="view-pricing">
          <Link href="/pricing">
            <TrendingUp className="w-4 h-4 mr-2" />
            Upgrade Plan
          </Link>
        </Button>
      </div>

      {/* Current Plan */}
      <Card className="glass-card border-2 border-primary/20" data-testid="current-plan-card">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div className="flex items-center space-x-3">
              <div className={`w-12 h-12 ${plan.color} rounded-lg flex items-center justify-center`}>
                {currentPlan === 'enterprise' ? (
                  <Crown className="w-6 h-6 text-white" />
                ) : currentPlan === 'production' || currentPlan === 'scale' ? (
                  <Shield className="w-6 h-6 text-white" />
                ) : (
                  <Zap className="w-6 h-6 text-white" />
                )}
              </div>
              <div>
                <CardTitle className="text-xl">{plan.name} Plan</CardTitle>
                <p className="text-muted-foreground">{plan.description}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">
                {plan.price > 0 ? formatCurrency(plan.price) : "Free"}
                {plan.period !== 'custom' && plan.period !== 'usage' && (
                  <span className="text-base font-normal text-muted-foreground">
                    /{plan.period}
                  </span>
                )}
                {plan.period === 'usage' && (
                  <span className="text-base font-normal text-muted-foreground">
                    Pay-as-you-go
                  </span>
                )}
              </div>
              {plan.price > 0 && (
                <div className="text-sm text-muted-foreground">
                  Next billing: {new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}
                </div>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {plan.tokensIncluded > 0 && (
            <div className="space-y-4 mb-6">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Token Usage</span>
                <span className="text-sm text-muted-foreground">
                  {formatNumber(tokenUsage)} / {formatNumber(plan.tokensIncluded)} tokens
                </span>
              </div>
              <Progress value={usagePercentage} className="h-2" data-testid="usage-progress" />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{usagePercentage.toFixed(1)}% used</span>
                <span>{formatNumber(plan.tokensIncluded - tokenUsage)} remaining</span>
              </div>
            </div>
          )}

          {overageCost > 0 && (
            <div className="mb-6 p-4 bg-orange-50 dark:bg-orange-950/20 border border-orange-200 dark:border-orange-800 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <AlertCircle className="w-4 h-4 text-orange-600" />
                <span className="text-sm font-medium text-orange-800 dark:text-orange-200">
                  Overage Usage
                </span>
              </div>
              <p className="text-sm text-orange-700 dark:text-orange-300">
                You've used {formatNumber(overageTokens)} tokens beyond your plan limit. 
                Additional charges: {formatCurrency(overageCost)}
              </p>
            </div>
          )}

          <div className="flex flex-wrap gap-2 mb-4">
            {plan.features.map((feature, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {feature}
              </Badge>
            ))}
          </div>

          <div className="flex space-x-4">
            <Button asChild data-testid="upgrade-plan-button">
              <Link href="/pricing">
                <TrendingUp className="w-4 h-4 mr-2" />
                Upgrade Plan
              </Link>
            </Button>
            <Button variant="outline" disabled data-testid="manage-plan-button">
              Manage Plan
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Payment Method & Billing History */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Payment Method */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center">
              <CreditCard className="w-5 h-5 mr-2" />
              Payment Method
            </CardTitle>
          </CardHeader>
          <CardContent>
            {currentPlan !== 'developer' ? (
              <div className="space-y-4">
                <div className="flex items-center space-x-4 p-4 border border-border rounded-lg">
                  <div className="w-12 h-8 bg-gradient-to-r from-blue-600 to-blue-800 rounded flex items-center justify-center">
                    <span className="text-white text-xs font-bold">VISA</span>
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">•••• •••• •••• 4242</div>
                    <div className="text-sm text-muted-foreground">Expires 12/28</div>
                  </div>
                  <Badge variant="default" className="text-xs">Primary</Badge>
                </div>

                <div className="flex space-x-2">
                  <Dialog open={isUpdatePaymentOpen} onOpenChange={setIsUpdatePaymentOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="flex-1" data-testid="update-payment-method">
                        Update Method
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Update Payment Method</DialogTitle>
                        <DialogDescription>
                          Update your payment method for future billing cycles.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="py-4">
                        <p className="text-muted-foreground">
                          Payment method updates are handled securely through Stripe. 
                          You'll be redirected to complete the process.
                        </p>
                      </div>
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" onClick={() => setIsUpdatePaymentOpen(false)}>
                          Cancel
                        </Button>
                        <Button>
                          Continue to Stripe
                          <ExternalLink className="w-4 h-4 ml-2" />
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                  <Button variant="outline" disabled data-testid="add-payment-method">
                    Add Method
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <CreditCard className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-medium mb-2">No Payment Method</h3>
                <p className="text-muted-foreground text-sm mb-4">
                  Your Developer plan is free. Upgrade to add a payment method.
                </p>
                <Button asChild variant="outline" data-testid="add-payment-for-upgrade">
                  <Link href="/pricing">
                    Upgrade to Add Payment
                  </Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center">
              <DollarSign className="w-5 h-5 mr-2" />
              This Month's Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Base Plan</span>
                <span className="font-medium">
                  {plan.price > 0 ? formatCurrency(plan.price) : "Free"}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Usage Overage</span>
                <span className="font-medium">
                  {formatCurrency(overageCost)}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Taxes & Fees</span>
                <span className="font-medium">$0.00</span>
              </div>
              <hr className="border-border" />
              <div className="flex justify-between items-center font-semibold text-lg">
                <span>Total Due</span>
                <span>{formatCurrency(plan.price + overageCost)}</span>
              </div>
              {plan.price > 0 && (
                <p className="text-xs text-muted-foreground">
                  Next billing date: {new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Billing History */}
      <Card className="glass-card">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center">
              <Calendar className="w-5 h-5 mr-2" />
              Billing History
            </CardTitle>
            <Button variant="outline" size="sm" disabled data-testid="download-invoices">
              <Download className="w-4 h-4 mr-2" />
              Download All
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {billingHistory.length > 0 ? (
            <div className="space-y-4">
              {billingHistory.slice(0, 10).map((record, index) => (
                <div
                  key={record.id}
                  className="flex justify-between items-center py-3 border-b border-border last:border-b-0"
                  data-testid={`billing-record-${index}`}
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <div>
                      <div className="font-medium">{record.description}</div>
                      <div className="text-sm text-muted-foreground">
                        {record.billingPeriodStart && record.billingPeriodEnd ? (
                          `${formatDate(record.billingPeriodStart)} - ${formatDate(record.billingPeriodEnd)}`
                        ) : (
                          formatDate(record.createdAt)
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">{formatCurrency(parseFloat(record.amount))}</div>
                    <div className="flex items-center space-x-2">
                      <Badge 
                        variant={record.status === 'paid' ? 'default' : 'secondary'}
                        className="text-xs"
                      >
                        {record.status}
                      </Badge>
                      <Button variant="ghost" size="sm" disabled>
                        <Download className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-medium mb-2">No Billing History</h3>
              <p className="text-muted-foreground text-sm">
                Your billing history will appear here once you start using paid features.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Help Section */}
      <Card className="glass-card border-blue-200 bg-blue-50/50 dark:border-blue-800 dark:bg-blue-950/20">
        <CardHeader>
          <CardTitle className="text-blue-800 dark:text-blue-200 flex items-center">
            <AlertCircle className="w-5 h-5 mr-2" />
            Need Help with Billing?
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-blue-700 dark:text-blue-300 mb-4">
            If you have questions about your billing, subscription, or need to update your payment information, 
            our support team is here to help.
          </p>
          <div className="flex space-x-4">
            <Button variant="outline" asChild data-testid="contact-support">
              <Link href="/help">Contact Support</Link>
            </Button>
            <Button variant="outline" asChild data-testid="view-pricing-help">
              <Link href="/pricing">View Pricing Details</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
