import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart3,
  DollarSign,
  Zap,
  TrendingUp,
  Clock,
  Download,
  RefreshCw,
  AlertCircle,
} from "lucide-react";

interface UsageStats {
  totalCost: number;
  totalTokens: number;
  totalRequests: number;
  modelBreakdown: Array<{
    model: string;
    requests: number;
    cost: number;
  }>;
}

interface UsageRecord {
  id: string;
  model: string;
  provider: string;
  requestType: string;
  tokensUsed: number;
  cost: string;
  timestamp: string;
}

export default function UsageAnalytics() {
  const { toast } = useToast();
  const [timeRange, setTimeRange] = useState("30d");
  const [selectedTab, setSelectedTab] = useState("overview");

  // Fetch usage statistics
  const { data: stats, isLoading: statsLoading, refetch: refetchStats, error: statsError } = useQuery({
    queryKey: ["/api/usage"],
  }) as { data: UsageStats | undefined; isLoading: boolean; refetch: () => void; error: any };

  // Handle stats fetch error
  if (statsError && isUnauthorizedError(statsError)) {
    toast({
      title: "Unauthorized",
      description: "You are logged out. Logging in again...",
      variant: "destructive",
    });
    setTimeout(() => {
      window.location.href = "/api/login";
    }, 500);
  }

  // Fetch usage history
  const { data: history = [], isLoading: historyLoading, error: historyError } = useQuery({
    queryKey: ["/api/usage/history"],
  }) as { data: UsageRecord[]; isLoading: boolean; error: any };

  // Handle history fetch error
  if (historyError && isUnauthorizedError(historyError)) {
    toast({
      title: "Unauthorized", 
      description: "You are logged out. Logging in again...",
      variant: "destructive",
    });
    setTimeout(() => {
      window.location.href = "/api/login";
    }, 500);
  }

  // Calculate daily usage for chart
  const dailyUsage = useMemo(() => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - i);
      return date.toISOString().split('T')[0];
    }).reverse();

    return last7Days.map(date => {
      const dayUsage = history.filter(record => 
        record.timestamp.startsWith(date)
      );
      
      return {
        date,
        cost: dayUsage.reduce((sum, record) => sum + parseFloat(record.cost), 0),
        requests: dayUsage.length,
        tokens: dayUsage.reduce((sum, record) => sum + record.tokensUsed, 0),
      };
    });
  }, [history]);

  const exportUsageData = () => {
    const exportData = {
      stats,
      history,
      dailyUsage,
      exportedAt: new Date().toISOString(),
      timeRange,
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: "application/json",
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `nuvra-ai-usage-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Usage Data Exported",
      description: "Your usage data has been downloaded successfully.",
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount);
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat("en-US").format(num);
  };

  if (statsLoading && historyLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-48"></div>
          <div className="grid grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded"></div>
            ))}
          </div>
          <div className="h-64 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Usage Analytics</h2>
          <p className="text-muted-foreground">
            Monitor your API usage and costs across all models
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32" data-testid="time-range-select">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            onClick={() => refetchStats()}
            disabled={statsLoading}
            data-testid="refresh-stats"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${statsLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button
            variant="outline"
            onClick={exportUsageData}
            disabled={!stats}
            data-testid="export-usage"
          >
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="glass-card" data-testid="total-cost-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Cost</p>
                <p className="text-3xl font-bold text-primary">
                  {stats ? formatCurrency(stats.totalCost) : "$0.00"}
                </p>
              </div>
              <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-primary" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">This month</p>
          </CardContent>
        </Card>

        <Card className="glass-card" data-testid="total-tokens-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Tokens Used</p>
                <p className="text-3xl font-bold text-accent">
                  {stats ? formatNumber(stats.totalTokens) : "0"}
                </p>
              </div>
              <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                <Zap className="w-6 h-6 text-accent" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Total tokens consumed</p>
          </CardContent>
        </Card>

        <Card className="glass-card" data-testid="total-requests-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">API Calls</p>
                <p className="text-3xl font-bold text-secondary">
                  {stats ? formatNumber(stats.totalRequests) : "0"}
                </p>
              </div>
              <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-secondary" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Successful requests</p>
          </CardContent>
        </Card>

        <Card className="glass-card" data-testid="uptime-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Uptime</p>
                <p className="text-3xl font-bold text-green-500">99.9%</p>
              </div>
              <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-500" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Service availability</p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Analytics */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
          <TabsTrigger value="models" data-testid="tab-models">Model Usage</TabsTrigger>
          <TabsTrigger value="history" data-testid="tab-history">Recent Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Daily Usage Chart */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Daily Usage (Last 7 Days)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-end justify-between space-x-2">
                  {dailyUsage.map((day, index) => {
                    const maxCost = Math.max(...dailyUsage.map(d => d.cost), 1);
                    const height = (day.cost / maxCost) * 100;
                    
                    return (
                      <div
                        key={day.date}
                        className="flex-1 flex flex-col items-center space-y-2"
                        data-testid={`daily-usage-${index}`}
                      >
                        <div
                          className="bg-primary rounded-t transition-all duration-500 ease-out min-h-[4px] w-full"
                          style={{ height: `${Math.max(height, 6)}%` }}
                          title={`${formatCurrency(day.cost)} on ${new Date(day.date).toLocaleDateString()}`}
                        />
                        <div className="text-xs text-muted-foreground text-center">
                          {new Date(day.date).toLocaleDateString('en-US', { 
                            month: 'short', 
                            day: 'numeric' 
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="mt-4 text-center">
                  <p className="text-sm text-muted-foreground">
                    Total: {formatCurrency(dailyUsage.reduce((sum, day) => sum + day.cost, 0))}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Cost Breakdown */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <DollarSign className="w-5 h-5 mr-2" />
                  Cost Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {stats?.modelBreakdown?.length ? (
                  stats.modelBreakdown
                    .sort((a, b) => b.cost - a.cost)
                    .slice(0, 5)
                    .map((model, index) => {
                      const percentage = ((model.cost / stats.totalCost) * 100).toFixed(1);
                      return (
                        <div key={model.model} className="space-y-2" data-testid={`model-breakdown-${index}`}>
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">{model.model}</span>
                            <div className="flex items-center space-x-2">
                              <span className="text-sm text-muted-foreground">{percentage}%</span>
                              <span className="text-sm font-medium">{formatCurrency(model.cost)}</span>
                            </div>
                          </div>
                          <div className="w-full bg-muted rounded-full h-2">
                            <div
                              className="bg-primary h-2 rounded-full transition-all duration-500"
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                      );
                    })
                ) : (
                  <div className="text-center py-8">
                    <AlertCircle className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">No usage data available</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="models" className="space-y-6">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle>Model Usage Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              {stats?.modelBreakdown?.length ? (
                <div className="space-y-6">
                  {stats.modelBreakdown
                    .sort((a, b) => b.requests - a.requests)
                    .map((model, index) => (
                      <div key={model.model} className="space-y-3" data-testid={`model-stats-${index}`}>
                        <div className="flex justify-between items-center">
                          <div className="flex items-center space-x-3">
                            <h4 className="font-semibold">{model.model}</h4>
                            <Badge variant="outline" className="text-xs">
                              {formatNumber(model.requests)} requests
                            </Badge>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold">{formatCurrency(model.cost)}</div>
                            <div className="text-xs text-muted-foreground">
                              {((model.requests / stats.totalRequests) * 100).toFixed(1)}% of total
                            </div>
                          </div>
                        </div>
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <div className="text-muted-foreground">Requests</div>
                            <div className="font-medium">{formatNumber(model.requests)}</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">Total Cost</div>
                            <div className="font-medium">{formatCurrency(model.cost)}</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">Avg Cost</div>
                            <div className="font-medium">
                              {formatCurrency(model.cost / model.requests)}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <AlertCircle className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No model usage data available</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="w-5 h-5 mr-2" />
                Recent API Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              {history.length > 0 ? (
                <div className="space-y-4">
                  {history.slice(0, 20).map((record, index) => (
                    <div
                      key={record.id}
                      className="flex justify-between items-center py-3 border-b border-border last:border-b-0"
                      data-testid={`activity-record-${index}`}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <div>
                          <div className="font-medium text-sm">
                            {record.requestType} completion
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {record.model} • {formatNumber(record.tokensUsed)} tokens
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-sm">
                          {formatCurrency(parseFloat(record.cost))}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {new Date(record.timestamp).toLocaleString()}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <AlertCircle className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No recent activity</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
