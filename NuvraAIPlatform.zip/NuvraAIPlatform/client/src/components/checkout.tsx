import { useState, useEffect } from "react";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CreditCard,
  Check,
  AlertCircle,
  Crown,
  Zap,
  Shield,
  ArrowRight,
  Lock,
} from "lucide-react";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface CheckoutFormProps {
  selectedPlan: string;
  onSuccess?: () => void;
}

const CheckoutForm = ({ selectedPlan, onSuccess }: CheckoutFormProps) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: window.location.origin + '/dashboard',
        },
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Payment Successful",
          description: `Welcome to ${selectedPlan}! Your subscription is now active.`,
        });
        onSuccess?.();
      }
    } catch (error) {
      toast({
        title: "Payment Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="p-4 border border-border rounded-lg bg-muted/20">
        <PaymentElement />
      </div>
      
      <Button
        type="submit"
        disabled={!stripe || isProcessing}
        className="w-full"
        data-testid="submit-payment"
      >
        {isProcessing ? (
          <>
            <div className="animate-spin w-4 h-4 border-2 border-current border-t-transparent rounded-full mr-2" />
            Processing...
          </>
        ) : (
          <>
            <Lock className="w-4 h-4 mr-2" />
            Complete Subscription
          </>
        )}
      </Button>

      <div className="text-center">
        <p className="text-xs text-muted-foreground">
          Payments are processed securely by Stripe. Your card information is never stored on our servers.
        </p>
      </div>
    </form>
  );
};

interface CheckoutProps {
  defaultPlan?: string;
}

export default function Checkout({ defaultPlan = "production" }: CheckoutProps) {
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState(defaultPlan);
  const [clientSecret, setClientSecret] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const plans = {
    production: {
      name: "Production",
      price: 50,
      description: "Perfect for mission-critical applications",
      features: [
        "100M tokens included",
        "Priority Support",
        "Fixed Pricing",
        "SLA guarantee",
        "Advanced analytics",
      ],
      icon: Shield,
      color: "bg-purple-500",
      popular: true,
    },
    scale: {
      name: "Scale",
      price: 200,
      description: "Built for high-volume applications",
      features: [
        "400M tokens included",
        "Personal manager",
        "Enterprise-grade reliability",
        "Custom integrations",
        "Phone support",
      ],
      icon: Zap,
      color: "bg-green-500",
      popular: false,
    },
    crypto: {
      name: "Pay In Crypto",
      price: 100,
      description: "Pay with cryptocurrency",
      features: [
        "200M tokens included",
        "Crypto payments (BTC, ETH)",
        "Privacy focused",
        "Enterprise reliability",
        "Personal manager",
      ],
      icon: Crown,
      color: "bg-orange-500",
      popular: false,
    },
  };

  const currentPlan = plans[selectedPlan as keyof typeof plans];

  useEffect(() => {
    if (selectedPlan && selectedPlan !== 'startup' && selectedPlan !== 'developer') {
      setIsLoading(true);
      // Create subscription when plan is selected
      apiRequest("POST", "/api/create-subscription", { plan: selectedPlan })
        .then((res) => res.json())
        .then((data) => {
          if (data.clientSecret) {
            setClientSecret(data.clientSecret);
          } else {
            throw new Error("No client secret received");
          }
        })
        .catch((error) => {
          console.error("Subscription creation error:", error);
          toast({
            title: "Subscription Error",
            description: "Failed to initialize subscription. Please try again.",
            variant: "destructive",
          });
        })
        .finally(() => {
          setIsLoading(false);
        });
    }
  }, [selectedPlan, toast]);

  const handlePlanChange = (newPlan: string) => {
    setSelectedPlan(newPlan);
    setClientSecret(""); // Reset client secret when plan changes
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center space-y-4">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto" />
            <h3 className="text-lg font-semibold">Setting up your subscription...</h3>
            <p className="text-muted-foreground">Please wait while we prepare your payment.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-2">Choose Your Plan</h1>
        <p className="text-muted-foreground">
          Select the plan that best fits your needs and complete your subscription.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Plan Selection */}
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-semibold mb-4">Select Plan</h2>
            <Select value={selectedPlan} onValueChange={handlePlanChange}>
              <SelectTrigger data-testid="plan-selector">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(plans).map(([key, plan]) => (
                  <SelectItem key={key} value={key}>
                    <div className="flex items-center space-x-2">
                      <span>{plan.name}</span>
                      <span className="text-muted-foreground">
                        - ${plan.price}/month
                      </span>
                      {plan.popular && (
                        <Badge variant="default" className="text-xs">Popular</Badge>
                      )}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Selected Plan Details */}
          <Card className="border-2 border-primary/20">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-12 h-12 ${currentPlan.color} rounded-lg flex items-center justify-center`}>
                    <currentPlan.icon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <CardTitle className="flex items-center space-x-2">
                      <span>{currentPlan.name}</span>
                      {currentPlan.popular && (
                        <Badge variant="default" className="text-xs">Popular</Badge>
                      )}
                    </CardTitle>
                    <p className="text-muted-foreground text-sm">{currentPlan.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold">
                    ${currentPlan.price}
                    <span className="text-base font-normal text-muted-foreground">/month</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className="text-sm font-medium">What's included:</p>
                <ul className="space-y-2">
                  {currentPlan.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm">
                      <Check className="w-4 h-4 text-green-500 mr-3 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Billing Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Billing Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>{currentPlan.name} Plan</span>
                  <span>${currentPlan.price}.00</span>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Billing cycle</span>
                  <span>Monthly</span>
                </div>
                <Separator />
                <div className="flex justify-between font-semibold">
                  <span>Total due today</span>
                  <span>${currentPlan.price}.00</span>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Next billing date</span>
                  <span>{new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Payment Form */}
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-semibold mb-4">Payment Information</h2>
            
            {!clientSecret ? (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <CreditCard className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="font-medium mb-2">Select a Plan</h3>
                    <p className="text-muted-foreground text-sm">
                      Choose your subscription plan to continue with payment setup.
                    </p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <CreditCard className="w-5 h-5 mr-2" />
                    Payment Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Elements 
                    stripe={stripePromise} 
                    options={{ 
                      clientSecret,
                      appearance: {
                        theme: 'stripe',
                        variables: {
                          colorPrimary: 'hsl(262, 83%, 58%)',
                        },
                      },
                    }}
                  >
                    <CheckoutForm 
                      selectedPlan={currentPlan.name}
                      onSuccess={() => {
                        toast({
                          title: "Subscription Active",
                          description: "Welcome to Nuvra AI! Your subscription is now active.",
                        });
                        // Redirect to dashboard after successful payment
                        setTimeout(() => {
                          window.location.href = '/dashboard';
                        }, 2000);
                      }}
                    />
                  </Elements>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Security Notice */}
          <Alert>
            <Lock className="h-4 w-4" />
            <AlertDescription>
              Your payment information is secured with industry-standard SSL encryption. 
              We never store your card details on our servers.
            </AlertDescription>
          </Alert>

          {/* Support */}
          <Card className="border-blue-200 bg-blue-50/50 dark:border-blue-800 dark:bg-blue-950/20">
            <CardContent className="pt-6">
              <div className="flex items-start space-x-3">
                <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm font-medium text-blue-800 dark:text-blue-200">
                    Need Help?
                  </p>
                  <p className="text-sm text-blue-700 dark:text-blue-300">
                    If you have any questions about billing or need assistance, 
                    our support team is available 24/7 to help you.
                  </p>
                  <Button variant="outline" size="sm" className="mt-2">
                    Contact Support
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
