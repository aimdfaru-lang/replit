import OpenAI from "openai";
import Anthropic from '@anthropic-ai/sdk';
import { GoogleGenAI } from "@google/genai";
import { createHash } from "crypto";

// Model configurations
const MODEL_CONFIGS = {
  "gpt-5": {
    provider: "openai",
    actualModel: "gpt-4", // Using GPT-4 as GPT-5 isn't available yet
    cost: { input: 0.01, output: 0.03 }, // per 1K tokens
  },
  "claude-sonnet-4": {
    provider: "anthropic",
    actualModel: "claude-3-5-sonnet-20241022", // Using latest available Claude
    cost: { input: 0.003, output: 0.015 },
  },
  "gemini-2-5-flash": {
    provider: "google",
    actualModel: "gemini-1.5-flash", // Using available Gemini model
    cost: { input: 0.0001, output: 0.0004 },
  },
  "gemini-2-0-flash": {
    provider: "google",
    actualModel: "gemini-1.5-flash",
    cost: { input: 0.0001, output: 0.0004 },
  },
  "gpt-4-1-mini": {
    provider: "openai",
    actualModel: "gpt-4o-mini",
    cost: { input: 0.00015, output: 0.0006 },
  },
  "deepseek-v3-0324": {
    provider: "openai", // DeepSeek uses OpenAI-compatible API
    actualModel: "deepseek-chat",
    baseUrl: "https://api.deepseek.com",
    cost: { input: 0.0001, output: 0.0002 },
  },
  "deepseek-v3-1": {
    provider: "openai",
    actualModel: "deepseek-chat",
    baseUrl: "https://api.deepseek.com",
    cost: { input: 0.0001, output: 0.0002 },
  },
  "gemini-2-5-pro": {
    provider: "google",
    actualModel: "gemini-1.5-pro",
    cost: { input: 0.001, output: 0.005 },
  },
  "qwen3-30b-a3b": {
    provider: "openai", // Qwen uses OpenAI-compatible API
    actualModel: "qwen-plus",
    baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1",
    cost: { input: 0.0001, output: 0.0002 },
  },
  "grok-code-fast-1": {
    provider: "xai",
    actualModel: "grok-2-1212",
    cost: { input: 0.002, output: 0.01 },
  },
};

// Initialize clients
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || "",
});

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY || "",
});

const gemini = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || "" 
});

const xai = new OpenAI({
  baseURL: "https://api.x.ai/v1",
  apiKey: process.env.XAI_API_KEY || "",
});

// Create DeepSeek client
const deepseek = new OpenAI({
  baseURL: "https://api.deepseek.com",
  apiKey: process.env.DEEPSEEK_API_KEY || "",
});

// Create Qwen client  
const qwen = new OpenAI({
  baseURL: "https://dashscope.aliyuncs.com/compatible-mode/v1",
  apiKey: process.env.QWEN_API_KEY || "",
});

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface ChatRequest {
  model: string;
  messages: ChatMessage[];
  temperature?: number;
  max_tokens?: number;
  top_p?: number;
}

export interface ChatResponse {
  id: string;
  model: string;
  choices: Array<{
    message: {
      role: string;
      content: string;
    };
    finish_reason: string;
  }>;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

export class AIProxy {
  async chatCompletion(request: ChatRequest): Promise<ChatResponse> {
    const modelConfig = MODEL_CONFIGS[request.model as keyof typeof MODEL_CONFIGS];
    if (!modelConfig) {
      throw new Error(`Model ${request.model} not supported`);
    }

    try {
      switch (modelConfig.provider) {
        case "openai":
          return await this.handleOpenAI(request, modelConfig);
        case "anthropic":
          return await this.handleAnthropic(request, modelConfig);
        case "google":
          return await this.handleGoogle(request, modelConfig);
        case "xai":
          return await this.handleXAI(request, modelConfig);
        default:
          throw new Error(`Provider ${modelConfig.provider} not implemented`);
      }
    } catch (error) {
      console.error(`Error with ${request.model}:`, error);
      throw new Error(`Failed to process request with ${request.model}: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async handleOpenAI(request: ChatRequest, config: any): Promise<ChatResponse> {
    let client = openai;
    
    // Use specific client for different providers
    if (config.baseUrl?.includes("deepseek")) {
      client = deepseek;
    } else if (config.baseUrl?.includes("dashscope")) {
      client = qwen;
    }

    const response = await client.chat.completions.create({
      model: config.actualModel,
      messages: request.messages,
      temperature: request.temperature || 0.7,
      max_tokens: request.max_tokens || 1000,
      top_p: request.top_p || 0.9,
    });

    return {
      id: response.id,
      model: request.model,
      choices: response.choices.map(choice => ({
        message: {
          role: choice.message.role,
          content: choice.message.content || "",
        },
        finish_reason: choice.finish_reason || "stop",
      })),
      usage: {
        prompt_tokens: response.usage?.prompt_tokens || 0,
        completion_tokens: response.usage?.completion_tokens || 0,
        total_tokens: response.usage?.total_tokens || 0,
      },
    };
  }

  private async handleAnthropic(request: ChatRequest, config: any): Promise<ChatResponse> {
    // Convert OpenAI format to Anthropic format
    const systemMessage = request.messages.find(m => m.role === "system");
    const conversationMessages = request.messages.filter(m => m.role !== "system");

    const response = await anthropic.messages.create({
      model: config.actualModel,
      system: systemMessage?.content,
      messages: conversationMessages.map(msg => ({
        role: msg.role === "assistant" ? "assistant" : "user",
        content: msg.content,
      })),
      max_tokens: request.max_tokens || 1000,
    });

    return {
      id: response.id,
      model: request.model,
      choices: [{
        message: {
          role: "assistant",
          content: Array.isArray(response.content) ? response.content.find(block => block.type === 'text')?.text || "" : "",
        },
        finish_reason: response.stop_reason || "stop",
      }],
      usage: {
        prompt_tokens: response.usage.input_tokens,
        completion_tokens: response.usage.output_tokens,
        total_tokens: response.usage.input_tokens + response.usage.output_tokens,
      },
    };
  }

  private async handleGoogle(request: ChatRequest, config: any): Promise<ChatResponse> {
    const model = gemini.models.generateContent;
    
    // Convert OpenAI format to Google format
    const systemMessage = request.messages.find(m => m.role === "system");
    const conversationMessages = request.messages.filter(m => m.role !== "system");
    
    const contents = conversationMessages.map(msg => ({
      role: msg.role === "assistant" ? "model" : "user",
      parts: [{ text: msg.content }],
    }));

    const response = await model({
      model: config.actualModel,
      config: {
        systemInstruction: systemMessage?.content,
        maxOutputTokens: request.max_tokens || 1000,
        temperature: request.temperature || 0.7,
        topP: request.top_p || 0.9,
      },
      contents,
    });

    return {
      id: createHash('md5').update(JSON.stringify(request)).digest('hex'),
      model: request.model,
      choices: [{
        message: {
          role: "assistant",
          content: response.text || "",
        },
        finish_reason: "stop",
      }],
      usage: {
        prompt_tokens: response.usageMetadata?.promptTokenCount || 0,
        completion_tokens: response.usageMetadata?.candidatesTokenCount || 0,
        total_tokens: response.usageMetadata?.totalTokenCount || 0,
      },
    };
  }

  private async handleXAI(request: ChatRequest, config: any): Promise<ChatResponse> {
    const response = await xai.chat.completions.create({
      model: config.actualModel,
      messages: request.messages,
      temperature: request.temperature || 0.7,
      max_tokens: request.max_tokens || 1000,
      top_p: request.top_p || 0.9,
    });

    return {
      id: response.id,
      model: request.model,
      choices: response.choices.map(choice => ({
        message: {
          role: choice.message.role,
          content: choice.message.content || "",
        },
        finish_reason: choice.finish_reason || "stop",
      })),
      usage: {
        prompt_tokens: response.usage?.prompt_tokens || 0,
        completion_tokens: response.usage?.completion_tokens || 0,
        total_tokens: response.usage?.total_tokens || 0,
      },
    };
  }

  calculateCost(model: string, usage: { prompt_tokens: number; completion_tokens: number }): number {
    const config = MODEL_CONFIGS[model as keyof typeof MODEL_CONFIGS];
    if (!config) return 0;

    const promptCost = (usage.prompt_tokens / 1000) * config.cost.input;
    const completionCost = (usage.completion_tokens / 1000) * config.cost.output;
    
    return promptCost + completionCost;
  }
}

export const aiProxy = new AIProxy();
