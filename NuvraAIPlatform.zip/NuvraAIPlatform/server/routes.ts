import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { storage } from "./storage";
import { aiProxy, type ChatRequest } from "./ai-proxy";
import { createHash } from "crypto";
import Stripe from "stripe";
import { z } from "zod";

// Initialize Stripe only if secret key is available
let stripe: Stripe | null = null;
if (process.env.STRIPE_SECRET_KEY) {
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
}

// Validation schemas
const chatRequestSchema = z.object({
  model: z.string(),
  messages: z.array(z.object({
    role: z.enum(["system", "user", "assistant"]),
    content: z.string(),
  })),
  temperature: z.number().min(0).max(2).optional(),
  max_tokens: z.number().min(1).max(4000).optional(),
  top_p: z.number().min(0).max(1).optional(),
});

const createApiKeySchema = z.object({
  name: z.string().min(1).max(100),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // API Key authentication middleware
  const authenticateApiKey = async (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Missing or invalid authorization header' });
    }

    const apiKey = authHeader.substring(7);
    const keyHash = createHash('sha256').update(apiKey).digest('hex');
    
    try {
      const apiKeyRecord = await storage.getApiKeyByHash(keyHash);
      if (!apiKeyRecord) {
        return res.status(401).json({ error: 'Invalid API key' });
      }

      // Update last used timestamp
      await storage.updateApiKeyLastUsed(apiKeyRecord.id);
      
      req.apiKey = apiKeyRecord;
      req.userId = apiKeyRecord.userId;
      next();
    } catch (error) {
      console.error('API key authentication error:', error);
      res.status(500).json({ error: 'Authentication failed' });
    }
  };

  // AI Chat Completion endpoint
  app.post('/api/v1/chat/completions', authenticateApiKey, async (req: any, res) => {
    try {
      const request = chatRequestSchema.parse(req.body);
      
      // Process the chat completion
      const response = await aiProxy.chatCompletion(request);
      
      // Calculate cost and record usage
      const cost = aiProxy.calculateCost(request.model, response.usage);
      
      await storage.recordUsage({
        userId: req.userId,
        apiKeyId: req.apiKey.id,
        model: request.model,
        provider: request.model.includes('gpt') ? 'openai' : 
                  request.model.includes('claude') ? 'anthropic' :
                  request.model.includes('gemini') ? 'google' :
                  request.model.includes('grok') ? 'xai' :
                  request.model.includes('deepseek') ? 'deepseek' : 'qwen',
        requestType: 'chat',
        tokensUsed: response.usage.total_tokens,
        cost: cost.toString(),
      });

      res.json(response);
    } catch (error) {
      console.error('Chat completion error:', error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: 'Invalid request format', details: error.errors });
      } else {
        res.status(500).json({ error: error instanceof Error ? error.message : 'Internal server error' });
      }
    }
  });

  // API Keys management
  app.get('/api/api-keys', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const apiKeys = await storage.getUserApiKeys(userId);
      res.json(apiKeys);
    } catch (error) {
      console.error('Error fetching API keys:', error);
      res.status(500).json({ message: 'Failed to fetch API keys' });
    }
  });

  app.post('/api/api-keys', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { name } = createApiKeySchema.parse(req.body);
      
      const { key, apiKey } = await storage.createApiKey(userId, name);
      
      res.json({ key, apiKey });
    } catch (error) {
      console.error('Error creating API key:', error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: 'Invalid request', details: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create API key' });
      }
    }
  });

  app.delete('/api/api-keys/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      await storage.deleteApiKey(id, userId);
      res.json({ success: true });
    } catch (error) {
      console.error('Error deleting API key:', error);
      res.status(500).json({ message: 'Failed to delete API key' });
    }
  });

  // Usage analytics
  app.get('/api/usage', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserUsageStats(userId);
      res.json(stats);
    } catch (error) {
      console.error('Error fetching usage stats:', error);
      res.status(500).json({ message: 'Failed to fetch usage stats' });
    }
  });

  app.get('/api/usage/history', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { start, end } = req.query;
      
      const startDate = start ? new Date(start as string) : undefined;
      const endDate = end ? new Date(end as string) : undefined;
      
      const usage = await storage.getUserUsage(userId, startDate, endDate);
      res.json(usage);
    } catch (error) {
      console.error('Error fetching usage history:', error);
      res.status(500).json({ message: 'Failed to fetch usage history' });
    }
  });

  // Billing routes
  app.get('/api/billing/history', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const history = await storage.getUserBillingHistory(userId);
      res.json(history);
    } catch (error) {
      console.error('Error fetching billing history:', error);
      res.status(500).json({ message: 'Failed to fetch billing history' });
    }
  });

  // Stripe subscription routes
  app.post('/api/create-subscription', isAuthenticated, async (req: any, res) => {
    try {
      if (!stripe) {
        return res.status(503).json({ error: 'Stripe billing is not configured' });
      }

      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const { plan } = req.body;

      if (!user?.email) {
        return res.status(400).json({ error: 'User email not found' });
      }

      // Plan to price mapping
      const planPrices = {
        production: process.env.STRIPE_PRODUCTION_PRICE_ID,
        scale: process.env.STRIPE_SCALE_PRICE_ID,
        crypto: process.env.STRIPE_CRYPTO_PRICE_ID,
      };

      const priceId = planPrices[plan as keyof typeof planPrices];
      if (!priceId) {
        return res.status(400).json({ error: 'Invalid plan selected' });
      }

      // Check if user already has a subscription
      if (user.stripeSubscriptionId) {
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
        return res.json({
          subscriptionId: subscription.id,
          clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
        });
      }

      // Create or get customer
      let customerId = user.stripeCustomerId;
      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user.email,
          metadata: { userId },
        });
        customerId = customer.id;
        await storage.updateUserStripeInfo(userId, customerId);
      }

      // Create subscription
      const subscription = await stripe.subscriptions.create({
        customer: customerId,
        items: [{ price: priceId }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });

      // Update user with subscription info
      await storage.updateUserStripeInfo(userId, customerId, subscription.id);

      res.json({
        subscriptionId: subscription.id,
        clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
      });
    } catch (error) {
      console.error('Subscription creation error:', error);
      res.status(500).json({ error: 'Failed to create subscription' });
    }
  });

  // Models list endpoint
  app.get('/api/models', (req, res) => {
    const models = [
      {
        id: "gpt-5",
        name: "GPT-5",
        provider: "OpenAI",
        type: "Chat",
        context: "400K tokens",
        status: "active",
        description: "Latest OpenAI model with multimodal capabilities"
      },
      {
        id: "claude-sonnet-4",
        name: "Claude Sonnet 4",
        provider: "Anthropic",
        type: "Chat", 
        context: "200K tokens",
        status: "active",
        description: "Advanced reasoning and analysis capabilities"
      },
      {
        id: "gemini-2-5-flash",
        name: "Gemini 2.5 Flash",
        provider: "Google",
        type: "Chat",
        context: "128K tokens", 
        status: "active",
        description: "Fast and efficient multimodal model"
      },
      {
        id: "gemini-2-0-flash",
        name: "Gemini 2.0 Flash",
        provider: "Google",
        type: "Chat",
        context: "128K tokens",
        status: "active", 
        description: "Latest version with improved performance"
      },
      {
        id: "gpt-4-1-mini",
        name: "GPT-4.1 Mini",
        provider: "OpenAI",
        type: "Chat",
        context: "128K tokens",
        status: "active",
        description: "Lightweight version for fast responses"
      },
      {
        id: "deepseek-v3-0324",
        name: "DeepSeek V3 0324",
        provider: "DeepSeek",
        type: "Chat",
        context: "128K tokens",
        status: "active",
        description: "Advanced coding and reasoning model"
      },
      {
        id: "deepseek-v3-1",
        name: "DeepSeek V3.1",
        provider: "DeepSeek", 
        type: "Chat",
        context: "128K tokens",
        status: "active",
        description: "Latest version with enhanced capabilities"
      },
      {
        id: "gemini-2-5-pro", 
        name: "Gemini 2.5 Pro",
        provider: "Google",
        type: "Chat",
        context: "200K tokens",
        status: "active",
        description: "Professional-grade multimodal model"
      },
      {
        id: "qwen3-30b-a3b",
        name: "Qwen3 30B A3B", 
        provider: "Alibaba",
        type: "Chat",
        context: "32K tokens",
        status: "active",
        description: "High-performance multilingual model"
      },
      {
        id: "grok-code-fast-1",
        name: "Grok Code Fast 1",
        provider: "xAI",
        type: "Code Generation",
        context: "128K tokens", 
        status: "active",
        description: "Specialized for fast code generation"
      }
    ];
    
    res.json(models);
  });

  const httpServer = createServer(app);
  return httpServer;
}
