import {
  users,
  apiKeys,
  usage,
  billingHistory,
  type User,
  type UpsertUser,
  type ApiKey,
  type InsertApiKey,
  type Usage,
  type InsertUsage,
  type BillingHistory,
  type InsertBillingHistory,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sum, count, and, gte, sql } from "drizzle-orm";
import { randomBytes, createHash } from "crypto";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // API Key operations
  createApiKey(userId: string, name: string): Promise<{ key: string; apiKey: ApiKey }>;
  getUserApiKeys(userId: string): Promise<ApiKey[]>;
  getApiKeyByHash(keyHash: string): Promise<ApiKey | undefined>;
  deleteApiKey(id: string, userId: string): Promise<void>;
  updateApiKeyLastUsed(id: string): Promise<void>;
  
  // Usage operations
  recordUsage(usage: InsertUsage): Promise<Usage>;
  getUserUsage(userId: string, startDate?: Date, endDate?: Date): Promise<Usage[]>;
  getUserUsageStats(userId: string): Promise<{
    totalCost: number;
    totalTokens: number;
    totalRequests: number;
    modelBreakdown: Array<{ model: string; requests: number; cost: number }>;
  }>;
  
  // Billing operations
  createBillingRecord(billing: InsertBillingHistory): Promise<BillingHistory>;
  getUserBillingHistory(userId: string): Promise<BillingHistory[]>;
  updateUserStripeInfo(userId: string, customerId?: string, subscriptionId?: string): Promise<User>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // API Key operations
  async createApiKey(userId: string, name: string): Promise<{ key: string; apiKey: ApiKey }> {
    // Generate a random API key
    const key = `nuvra-${randomBytes(32).toString('hex')}`;
    const keyHash = createHash('sha256').update(key).digest('hex');
    const keyPreview = `${key.substring(0, 12)}...${key.substring(key.length - 6)}`;

    const [apiKey] = await db
      .insert(apiKeys)
      .values({
        userId,
        name,
        keyHash,
        keyPreview,
      })
      .returning();

    return { key, apiKey };
  }

  async getUserApiKeys(userId: string): Promise<ApiKey[]> {
    return await db
      .select()
      .from(apiKeys)
      .where(and(eq(apiKeys.userId, userId), eq(apiKeys.isActive, true)))
      .orderBy(desc(apiKeys.createdAt));
  }

  async getApiKeyByHash(keyHash: string): Promise<ApiKey | undefined> {
    const [apiKey] = await db
      .select()
      .from(apiKeys)
      .where(and(eq(apiKeys.keyHash, keyHash), eq(apiKeys.isActive, true)));
    return apiKey;
  }

  async deleteApiKey(id: string, userId: string): Promise<void> {
    await db
      .update(apiKeys)
      .set({ isActive: false })
      .where(and(eq(apiKeys.id, id), eq(apiKeys.userId, userId)));
  }

  async updateApiKeyLastUsed(id: string): Promise<void> {
    await db
      .update(apiKeys)
      .set({ lastUsed: new Date() })
      .where(eq(apiKeys.id, id));
  }

  // Usage operations
  async recordUsage(usageData: InsertUsage): Promise<Usage> {
    const [newUsage] = await db.insert(usage).values(usageData).returning();
    return newUsage;
  }

  async getUserUsage(userId: string, startDate?: Date, endDate?: Date): Promise<Usage[]> {
    let whereConditions = [eq(usage.userId, userId)];
    
    if (startDate && endDate) {
      whereConditions.push(
        gte(usage.timestamp, startDate),
        sql`${usage.timestamp} <= ${endDate}`
      );
    }
    
    return await db
      .select()
      .from(usage)
      .where(and(...whereConditions))
      .orderBy(desc(usage.timestamp));
  }

  async getUserUsageStats(userId: string): Promise<{
    totalCost: number;
    totalTokens: number;
    totalRequests: number;
    modelBreakdown: Array<{ model: string; requests: number; cost: number }>;
  }> {
    // Get current month's usage
    const startOfMonth = new Date();
    startOfMonth.setDate(1);
    startOfMonth.setHours(0, 0, 0, 0);

    const stats = await db
      .select({
        totalCost: sql<number>`COALESCE(SUM(${usage.cost}), 0)`,
        totalTokens: sql<number>`COALESCE(SUM(${usage.tokensUsed}), 0)`,
        totalRequests: sql<number>`COUNT(*)`,
      })
      .from(usage)
      .where(and(eq(usage.userId, userId), gte(usage.timestamp, startOfMonth)));

    const modelBreakdown = await db
      .select({
        model: usage.model,
        requests: sql<number>`COUNT(*)`,
        cost: sql<number>`COALESCE(SUM(${usage.cost}), 0)`,
      })
      .from(usage)
      .where(and(eq(usage.userId, userId), gte(usage.timestamp, startOfMonth)))
      .groupBy(usage.model);

    return {
      totalCost: stats[0]?.totalCost || 0,
      totalTokens: stats[0]?.totalTokens || 0,
      totalRequests: stats[0]?.totalRequests || 0,
      modelBreakdown: modelBreakdown || [],
    };
  }

  // Billing operations
  async createBillingRecord(billingData: InsertBillingHistory): Promise<BillingHistory> {
    const [billing] = await db.insert(billingHistory).values(billingData).returning();
    return billing;
  }

  async getUserBillingHistory(userId: string): Promise<BillingHistory[]> {
    return await db
      .select()
      .from(billingHistory)
      .where(eq(billingHistory.userId, userId))
      .orderBy(desc(billingHistory.createdAt));
  }

  async updateUserStripeInfo(userId: string, customerId?: string, subscriptionId?: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        stripeCustomerId: customerId,
        stripeSubscriptionId: subscriptionId,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }
}

export const storage = new DatabaseStorage();
